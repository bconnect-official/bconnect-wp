<?php
/**
 * Nettoyage à la désinstallation.
 *
 * Toujours supprimés : options du plugin, journal, transients.
 * Supprimés uniquement si le marchand a coché l'option dédiée :
 * appairages (_bconnect_sub) et métadonnées utilisateur b.connect —
 * par défaut on les conserve pour ne pas casser les appairages en cas
 * de réinstallation.
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

$bconnect_settings = get_option( 'bconnect_settings', array() );
$bconnect_purge    = is_array( $bconnect_settings ) && ! empty( $bconnect_settings['delete_on_uninstall'] );

delete_option( 'bconnect_settings' );
delete_option( 'bconnect_log' );

global $wpdb;
$wpdb->query(
	"DELETE FROM {$wpdb->options} WHERE option_name LIKE '\_transient\_bconnect\_%' OR option_name LIKE '\_transient\_timeout\_bconnect\_%'"
);

if ( $bconnect_purge ) {
	delete_metadata( 'user', 0, '_bconnect_sub', '', true );
	delete_metadata( 'user', 0, '_bconnect_civility', '', true );
	delete_metadata( 'user', 0, '_bconnect_birthdate', '', true );
	delete_metadata( 'user', 0, '_bconnect_phone', '', true );
	delete_metadata( 'user', 0, '_bconnect_postaladdress', '', true );
}
