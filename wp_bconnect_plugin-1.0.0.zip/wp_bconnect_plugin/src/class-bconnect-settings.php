<?php
defined( 'ABSPATH' ) || exit;

/**
 * Accès centralisé à la configuration du plugin.
 *
 * Option unique `bconnect_settings` (tableau). Le client_secret y est stocké
 * en base comme toute option WordPress : il n'est jamais ré-affiché en clair
 * dans l'admin après enregistrement.
 */
class BConnect_Settings {

	const OPTION_KEY = 'bconnect_settings';

	const ENV_MOCK          = 'mock';
	const ENV_QUALIFICATION = 'qualification';
	const ENV_PRODUCTION    = 'production';

	/**
	 * Endpoints OIDC officiels, centralisés en dur par environnement.
	 *
	 * Le marchand ne saisit plus ces URLs : le choix d'environnement
	 * sélectionne automatiquement le bon jeu. `aud` = audience officielle
	 * éventuelle (vide par défaut → on retombe sur le client_id).
	 *
	 * Qualification et Production sont renseignés avec leurs valeurs officielles
	 * b.connect. Un environnement dont les 4 endpoints seraient vides serait
	 * considéré indisponible (voir environment_available()) et ne pourrait être
	 * ni activé ni utilisé (is_configured() resterait false).
	 */
	public static function endpoint_map(): array {
		return array(
			self::ENV_QUALIFICATION => array(
				'issuer'             => 'https://api.bconnect-qualif.net/sso/v2/oauth2/bconnect',
				'authorize_endpoint' => 'https://bconnect-qualif.net/a/oauth2/authorize',
				'token_endpoint'     => 'https://api.bconnect-qualif.net/sso/v2/oauth2/bconnect/access_token',
				'jwks_endpoint'      => 'https://api.bconnect-qualif.net/sso/v2/oauth2/bconnect/connect/jwk_uri',
				'aud'                => '',
			),
			self::ENV_PRODUCTION => array(
				'issuer'             => 'https://api.bconnect.net/sso/v2/oauth2/bconnect',
				'authorize_endpoint' => 'https://bconnect.net/a/oauth2/authorize',
				'token_endpoint'     => 'https://api.bconnect.net/sso/v2/oauth2/bconnect/access_token',
				'jwks_endpoint'      => 'https://api.bconnect.net/sso/v2/oauth2/bconnect/connect/jwk_uri',
				'aud'                => '',
			),
		);
	}

	/** Endpoints effectifs de l'environnement courant (jamais les valeurs stockées en base). */
	public static function endpoints(): array {
		$map = self::endpoint_map();
		return $map[ self::environment() ] ?? array(
			'issuer'             => '',
			'authorize_endpoint' => '',
			'token_endpoint'     => '',
			'jwks_endpoint'      => '',
			'aud'                => '',
		);
	}

	/** Un environnement est disponible si ses 4 endpoints officiels sont renseignés. */
	public static function environment_available( string $env ): bool {
		$map = self::endpoint_map();
		if ( ! isset( $map[ $env ] ) ) {
			return false;
		}
		foreach ( array( 'issuer', 'authorize_endpoint', 'token_endpoint', 'jwks_endpoint' ) as $k ) {
			if ( '' === trim( (string) ( $map[ $env ][ $k ] ?? '' ) ) ) {
				return false;
			}
		}
		return true;
	}

	/** Scopes proposés : slug => [libellé, verrouillé, actif par défaut]. */
	public static function scope_catalog(): array {
		return array(
			'openid'        => array( 'openid (identifiant technique sub)', true, true ),
			'email'         => array( 'email (requis pour appairage et création de compte)', true, true ),
			'given_name'    => array( 'given_name (prénom)', false, true ),
			'family_name'   => array( 'family_name (nom)', false, true ),
			'civility'      => array( 'civility (civilité)', false, true ),
			'birthdate'     => array( 'birthdate (date de naissance)', false, true ),
			'phone'         => array( 'phone (téléphone — uniquement si le site l\'exploite déjà)', false, false ),
			'postaladdress' => array( 'postaladdress (adresse postale — uniquement si le site l\'exploite déjà)', false, false ),
		);
	}

	/**
	 * Scopes optionnels temporairement verrouillés en qualification et en production.
	 *
	 * Le portail FS passe en production avant b.connect v2 (décalage de quelques
	 * semaines) : civility/birthdate seraient source d'erreur tant que b.connect
	 * v2 n'est pas lui-même en production. Verrouillés dès la qualification pour que
	 * la recette reflète le comportement de la V1 livrée. Sans effet en mock (tests
	 * internes) — verrou à retirer une fois b.connect v2 confirmé en production par
	 * le client.
	 */
	public static function restricted_scopes(): array {
		return array( 'civility', 'birthdate' );
	}

	public static function defaults(): array {
		$scopes = array();
		foreach ( self::scope_catalog() as $slug => $def ) {
			if ( $def[2] ) {
				$scopes[] = $slug;
			}
		}
		return array(
			'environment'        => self::ENV_PRODUCTION,
			'client_id'          => '',
			'client_secret'      => '',
			'issuer'             => '',
			'authorize_endpoint' => '',
			'token_endpoint'     => '',
			'jwks_endpoint'      => '',
			'scopes'             => $scopes,
			'auto_display'       => true,
			'button_align'       => 'left',
			'button_theme'       => 'blue',
			'mock_enabled'       => false,
			'aud_mode'           => 'client_id', // Sémantique du claim aud à confirmer avec b.connect (ex. reçu : "app-mysp-cprod").
			'aud_custom'         => '',
			'delete_on_uninstall'=> false,
		);
	}

	/** Alignements proposés pour le bouton placé via le shortcode. */
	public static function button_align_choices(): array {
		return array(
			'left'   => __( 'Gauche (par défaut)', 'wp_bconnect_plugin' ),
			'center' => __( 'Centré', 'wp_bconnect_plugin' ),
		);
	}

	/** Thèmes visuels proposés pour le bouton (contexte "link" toujours en bleu, seule variante disponible). */
	public static function button_theme_choices(): array {
		return array(
			'blue'  => __( 'Bleu (par défaut)', 'wp_bconnect_plugin' ),
			'white' => __( 'Blanc', 'wp_bconnect_plugin' ),
		);
	}

	public static function activate(): void {
		if ( false === get_option( self::OPTION_KEY, false ) ) {
			add_option( self::OPTION_KEY, self::defaults() );
		}
	}

	public static function all(): array {
		$saved = get_option( self::OPTION_KEY, array() );
		return wp_parse_args( is_array( $saved ) ? $saved : array(), self::defaults() );
	}

	public static function get( string $key ) {
		// Les endpoints OIDC proviennent de la config interne par environnement,
		// jamais des anciennes valeurs éventuellement encore stockées en base.
		if ( in_array( $key, array( 'issuer', 'authorize_endpoint', 'token_endpoint', 'jwks_endpoint' ), true ) ) {
			$ep = self::endpoints();
			return $ep[ $key ] ?? '';
		}
		$all = self::all();
		return $all[ $key ] ?? null;
	}

	public static function update( array $partial ): void {
		update_option( self::OPTION_KEY, array_merge( self::all(), $partial ) );
	}

	public static function environment(): string {
		// Installation fraîche / clé absente : all() fournit déjà le défaut
		// « qualification ». En revanche une valeur explicitement enregistrée
		// mais inconnue (ex. « staging ») n'est jamais réécrite silencieusement :
		// on échoue fermé (chaîne vide) → endpoints vides, is_configured/is_ready
		// false, status non_configure, aucun bouton public.
		$all = self::all();
		$env = $all['environment'] ?? self::ENV_QUALIFICATION;
		return in_array( $env, array( self::ENV_MOCK, self::ENV_QUALIFICATION, self::ENV_PRODUCTION ), true ) ? $env : '';
	}

	/** Mode mock actif : environnement mock ET case explicitement cochée. */
	public static function is_mock(): bool {
		return self::ENV_MOCK === self::environment() && (bool) self::get( 'mock_enabled' );
	}

	/** Configuration OIDC réelle complète (hors mock). */
	public static function is_configured(): bool {
		// Credentials fournis par le marchand (stockés en base).
		foreach ( array( 'client_id', 'client_secret' ) as $k ) {
			if ( '' === trim( (string) self::get( $k ) ) ) {
				return false;
			}
		}
		// Endpoints effectifs de l'environnement courant (config interne) :
		// vides = environnement indisponible (ex. production non communiquée).
		foreach ( array( 'issuer', 'authorize_endpoint', 'token_endpoint', 'jwks_endpoint' ) as $k ) {
			if ( '' === trim( (string) self::get( $k ) ) ) {
				return false;
			}
		}
		return true;
	}

	/** Le bouton public peut-il être affiché / le flow lancé ? */
	public static function is_ready(): bool {
		return self::is_mock() || ( self::environment() !== self::ENV_MOCK && self::is_configured() );
	}

	/** Statut lisible pour l'admin : non_configure | mock | qualification | production. */
	public static function status(): string {
		if ( self::is_mock() ) {
			return 'mock';
		}
		if ( self::environment() !== self::ENV_MOCK && self::is_configured() ) {
			return self::environment();
		}
		return 'non_configure';
	}

	/** redirect_uri unique du site, à déclarer côté b.connect. */
	public static function redirect_uri(): string {
		return add_query_arg( 'bconnect', 'callback', home_url( '/' ) );
	}

	/** Chaîne de scopes pour la requête authorize. */
	public static function scope_string(): string {
		$scopes = (array) self::get( 'scopes' );
		// openid et email toujours présents.
		$scopes = array_unique( array_merge( array( 'openid', 'email' ), $scopes ) );
		$valid  = array_keys( self::scope_catalog() );
		$scopes = array_values( array_intersect( $scopes, $valid ) );
		// Verrou runtime : civility/birthdate ne sont jamais envoyés en
		// qualification/production, même si une ancienne option encore stockée les
		// contient (l'enforcement à la sauvegarde ne suffit pas tant que l'admin n'a
		// pas ré-enregistré). Conservés en mock pour les tests internes.
		if ( in_array( self::environment(), array( self::ENV_QUALIFICATION, self::ENV_PRODUCTION ), true ) ) {
			$scopes = array_values( array_diff( $scopes, self::restricted_scopes() ) );
		}
		return implode( ' ', $scopes );
	}

	/**
	 * Valeur attendue pour le claim aud.
	 *
	 * Audience officielle de l'environnement si la config interne en définit
	 * une (non vide), sinon le client_id (défaut OIDC). La comparaison réelle
	 * reste inchangée côté BConnect_JWT_Validator.
	 */
	public static function expected_aud(): string {
		$ep  = self::endpoints();
		$aud = trim( (string) ( $ep['aud'] ?? '' ) );
		if ( '' !== $aud ) {
			return $aud;
		}
		return (string) self::get( 'client_id' );
	}
}
