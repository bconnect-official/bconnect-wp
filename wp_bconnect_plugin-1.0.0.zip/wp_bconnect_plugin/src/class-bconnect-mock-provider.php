<?php
defined( 'ABSPATH' ) || exit;

/**
 * Fournisseur simulé pour le développement local, sans aucun appel réseau.
 *
 * Uniquement actif si environnement = mock ET option mock_enabled cochée
 * (double opt-in, jamais silencieux — bandeau visible en admin et badge
 * sur le bouton). Aucune donnée réelle : domaines example.test uniquement.
 */
class BConnect_Mock_Provider {

	/**
	 * Profils simulés. Chaque profil couvre un scénario fonctionnel V1.
	 * `claims` = ce que renverrait b.connect ; `error` = erreur au callback ;
	 * `invalid` = tokens reçus mais rejetés à la validation (scénario 16).
	 */
	public static function profiles(): array {
		return array(
			'mock_existing_linked' => array(
				'label'  => 'Utilisateur déjà appairé (2e passage) / nouveau compte au 1er passage',
				'claims' => array(
					'sub'            => 'mock-sub-001',
					'email'          => 'client.mock@example.test',
					'email_verified' => true,
					'given_name'     => 'Jean',
					'family_name'    => 'Dupont',
					'civility'       => 'M',
					'birthdate'      => '1985-04-12',
				),
			),
			'mock_existing_email' => array(
				'label'  => 'Appairage auto par email (créer d\'abord un compte WP avec cet email)',
				'claims' => array(
					'sub'            => 'mock-sub-002',
					'email'          => 'marie.durand@example.test',
					'email_verified' => true,
					'given_name'     => 'Marie',
					'family_name'    => 'Durand',
					'civility'       => 'MME',
					'birthdate'      => '1990-09-23',
				),
			),
			'mock_new_user' => array(
				'label'  => 'Création automatique d\'un nouveau compte',
				'claims' => array(
					'sub'            => 'mock-sub-003',
					'email'          => 'nouveau.client@example.test',
					'email_verified' => true,
					'given_name'     => 'Paul',
					'family_name'    => 'Martin',
					'civility'       => 'M',
					'birthdate'      => '1978-01-30',
				),
			),
			'mock_missing_email' => array(
				'label'  => 'Email absent des claims (pas de création automatique)',
				'claims' => array(
					'sub'         => 'mock-sub-004',
					'given_name'  => 'Anonyme',
					'family_name' => 'SansEmail',
				),
			),
			'mock_invalid_token' => array(
				'label'   => 'id_token invalide / rejeté (scénario sécurité 16)',
				'invalid' => 'jwt_bad_signature',
			),
			'mock_cancel' => array(
				'label' => 'Annulation volontaire de l\'utilisateur (scénario 14)',
				'error' => 'access_denied',
			),
			'mock_error' => array(
				'label' => 'Erreur technique b.connect (scénario 15)',
				'error' => 'server_error',
			),
			'mock_conflict_sub' => array(
				'label'  => 'Conflit de sub — même sub que le profil 001 (scénario 17, à tester depuis un autre compte connecté)',
				'claims' => array(
					'sub'            => 'mock-sub-001',
					'email'          => 'autre.email@example.test',
					'email_verified' => true,
					'given_name'     => 'Jean',
					'family_name'    => 'Imposteur',
				),
			),
		);
	}

	/**
	 * Écran d'autorisation simulé : liste les profils comme le ferait
	 * la mire b.connect. Chaque lien renvoie vers le callback du plugin.
	 */
	public function render_authorize_screen( string $state ): void {
		$callback = BConnect_Settings::redirect_uri();

		$items = '';
		foreach ( self::profiles() as $slug => $profile ) {
			if ( isset( $profile['error'] ) ) {
				$url = add_query_arg( array( 'error' => $profile['error'], 'state' => $state ), $callback );
			} else {
				$url = add_query_arg( array( 'code' => 'mockcode-' . $slug, 'state' => $state ), $callback );
			}
			$items .= '<li><a href="' . esc_url( $url ) . '"><strong>' . esc_html( $slug ) . '</strong> — ' . esc_html( $profile['label'] ) . '</a></li>';
		}

		// Page volontairement rudimentaire : simulateur de dev, jamais exposé hors mode mock.
		header( 'Content-Type: text/html; charset=utf-8' );
		echo '<!DOCTYPE html><html lang="fr"><head><meta charset="utf-8"><title>Simulateur b.connect (MOCK)</title>';
		echo '<style>body{font:16px/1.6 system-ui;max-width:640px;margin:3rem auto;padding:0 1rem;color:#1a1a2e}
			.badge{background:#c0392b;color:#fff;padding:.2em .6em;border-radius:4px;font-size:.8em}
			ul{list-style:none;padding:0}li{margin:.6em 0}a{color:#16326e;text-decoration:none}a:hover{text-decoration:underline}</style></head><body>';
		echo '<h1>Simulateur b.connect <span class="badge">MODE MOCK — DEV UNIQUEMENT</span></h1>';
		echo '<p>Choisissez un profil pour simuler le retour b.connect :</p>';
		echo '<ul>' . $items . '</ul>'; // phpcs:ignore WordPress.Security.EscapeOutput -- construit ci-dessus avec esc_url/esc_html.
		echo '</body></html>';
		exit;
	}

	/**
	 * Équivalent mock de « échange code + validation id_token ».
	 *
	 * @return array|WP_Error Claims simulés, ou erreur de validation simulée.
	 */
	public function exchange_and_validate( string $code ) {
		$slug     = preg_replace( '/^mockcode-/', '', $code );
		$profiles = self::profiles();

		if ( ! isset( $profiles[ $slug ] ) ) {
			return new WP_Error( 'mock_unknown_code', 'code mock inconnu' );
		}
		$profile = $profiles[ $slug ];

		if ( isset( $profile['invalid'] ) ) {
			return new WP_Error( $profile['invalid'], 'validation id_token simulée en échec (profil ' . $slug . ')' );
		}
		return $profile['claims'];
	}
}
