<?php
defined( 'ABSPATH' ) || exit;

/**
 * Gestion de l'appairage depuis l'espace utilisateur (scénarios 10/11/18) :
 * profil WordPress + tableau de bord « Mon compte » WooCommerce.
 */
class BConnect_Account {

	private static ?BConnect_Account $instance = null;

	public static function instance(): BConnect_Account {
		return self::$instance ??= new self();
	}

	public function register_hooks(): void {
		add_action( 'show_user_profile', array( $this, 'render_profile_section' ) );
		add_action( 'woocommerce_account_dashboard', array( $this, 'render_account_section' ) );
		add_action( 'admin_post_bconnect_unlink', array( $this, 'handle_unlink' ) );
	}

	/** Section profil WordPress (utilisateur sur son propre profil). */
	public function render_profile_section( WP_User $user ): void {
		if ( get_current_user_id() !== (int) $user->ID ) {
			return;
		}
		echo '<h2>' . esc_html__( 'b.connect', 'wp_bconnect_plugin' ) . '</h2>';
		$this->render_status_block();
	}

	/** Bloc « Mon compte » WooCommerce. */
	public function render_account_section(): void {
		echo '<section class="bconnect-account">';
		echo '<h2>' . esc_html__( 'Connexion b.connect', 'wp_bconnect_plugin' ) . '</h2>';
		$this->render_status_block();
		echo '</section>';
	}

	private function render_status_block(): void {
		if ( ! is_user_logged_in() ) {
			return;
		}
		$resolver = new BConnect_User_Resolver();
		$user_id  = get_current_user_id();

		$notice = BConnect_Callback::current_notice();
		if ( '' !== $notice ) {
			echo '<p class="bconnect-notice">' . esc_html( $notice ) . '</p>';
		}

		if ( $resolver->is_linked( $user_id ) ) {
			echo '<p>' . esc_html__( 'Votre compte est lié à b.connect.', 'wp_bconnect_plugin' ) . '</p>';
			echo '<p class="description">' . esc_html__( 'Si vous n\'avez jamais défini de mot de passe sur ce site, pensez à en créer un via « Mot de passe oublié » avant de dissocier b.connect, afin de conserver un accès classique.', 'wp_bconnect_plugin' ) . '</p>';

			$unlink_url = wp_nonce_url(
				add_query_arg( 'action', 'bconnect_unlink', admin_url( 'admin-post.php' ) ),
				'bconnect_unlink'
			);
			echo '<p><a class="button bconnect-unlink" href="' . esc_url( $unlink_url ) . '">' . esc_html__( 'Dissocier mon compte b.connect', 'wp_bconnect_plugin' ) . '</a></p>';
		} else {
			echo '<p>' . esc_html__( 'Votre compte n\'est pas encore lié à b.connect.', 'wp_bconnect_plugin' ) . '</p>';
			if ( BConnect_Settings::is_ready() ) {
				echo BConnect_Button::instance()->render( 'link' ); // phpcs:ignore WordPress.Security.EscapeOutput -- template échappé.
			}
		}
	}

	/** Dissociation (nonce + session obligatoires). */
	public function handle_unlink(): void {
		if ( ! is_user_logged_in() ) {
			wp_die( esc_html__( 'Action non autorisée.', 'wp_bconnect_plugin' ), '', 403 );
		}
		check_admin_referer( 'bconnect_unlink' );

		( new BConnect_User_Resolver() )->unlink( get_current_user_id() );

		$destination = function_exists( 'wc_get_page_permalink' ) && wc_get_page_permalink( 'myaccount' )
			? wc_get_page_permalink( 'myaccount' )
			: admin_url( 'profile.php' );

		wp_safe_redirect( add_query_arg( 'bconnect_notice', 'unlinked', $destination ) );
		exit;
	}
}
