<?php
defined( 'ABSPATH' ) || exit;

/**
 * Validation d'un id_token OIDC signé RS256 via JWKS, sans dépendance externe.
 *
 * Contrôles : signature, alg, iss, aud, exp/iat (leeway 60 s), nonce.
 * En cas d'échec : WP_Error avec un code précis pour le journal admin
 * (scénario 16) — l'utilisateur ne voit qu'un message générique.
 */
class BConnect_JWT_Validator {

	const JWKS_CACHE_KEY = 'bconnect_jwks_cache';
	const JWKS_CACHE_TTL = 12 * HOUR_IN_SECONDS;
	const LEEWAY         = 60;

	/**
	 * @return array|WP_Error Claims du token si valide.
	 */
	public function validate( string $id_token, string $expected_nonce ) {
		$parts = explode( '.', $id_token );
		if ( 3 !== count( $parts ) ) {
			return new WP_Error( 'jwt_malformed', 'id_token malformé (3 segments attendus)' );
		}

		$header = json_decode( $this->b64url_decode( $parts[0] ), true );
		$claims = json_decode( $this->b64url_decode( $parts[1] ), true );
		if ( ! is_array( $header ) || ! is_array( $claims ) ) {
			return new WP_Error( 'jwt_malformed', 'header ou payload id_token illisible' );
		}

		if ( ( $header['alg'] ?? '' ) !== 'RS256' ) {
			return new WP_Error( 'jwt_bad_alg', 'algorithme inattendu : ' . sanitize_text_field( $header['alg'] ?? '(absent)' ) );
		}

		$sig_check = $this->verify_signature( $parts, (string) ( $header['kid'] ?? '' ) );
		if ( is_wp_error( $sig_check ) ) {
			return $sig_check;
		}

		$issuer = (string) BConnect_Settings::get( 'issuer' );
		if ( ! isset( $claims['iss'] ) || untrailingslashit( $claims['iss'] ) !== untrailingslashit( $issuer ) ) {
			return new WP_Error( 'jwt_bad_iss', 'issuer inattendu' );
		}

		$expected_aud = BConnect_Settings::expected_aud();
		$aud          = (array) ( $claims['aud'] ?? array() );
		if ( '' === $expected_aud || ! in_array( $expected_aud, $aud, true ) ) {
			return new WP_Error( 'jwt_bad_aud', 'audience inattendue (sémantique aud à confirmer avec b.connect)' );
		}

		$now = time();
		if ( ! isset( $claims['exp'] ) || $now > (int) $claims['exp'] + self::LEEWAY ) {
			return new WP_Error( 'jwt_expired', 'id_token expiré' );
		}
		if ( isset( $claims['iat'] ) && (int) $claims['iat'] > $now + self::LEEWAY ) {
			return new WP_Error( 'jwt_bad_iat', 'iat dans le futur' );
		}

		if ( '' === $expected_nonce || ( $claims['nonce'] ?? '' ) !== $expected_nonce ) {
			return new WP_Error( 'jwt_bad_nonce', 'nonce absent ou différent de celui émis' );
		}

		return $claims;
	}

	/** @return true|WP_Error */
	private function verify_signature( array $parts, string $kid ) {
		$key = $this->find_key( $kid );
		if ( is_wp_error( $key ) ) {
			return $key;
		}

		$pem = $this->jwk_to_pem( $key );
		if ( is_wp_error( $pem ) ) {
			return $pem;
		}

		$signed  = $parts[0] . '.' . $parts[1];
		$sig     = $this->b64url_decode( $parts[2] );
		$ok      = openssl_verify( $signed, $sig, $pem, OPENSSL_ALGO_SHA256 );
		if ( 1 !== $ok ) {
			return new WP_Error( 'jwt_bad_signature', 'signature RS256 invalide' );
		}
		return true;
	}

	/**
	 * Récupère la clé JWKS correspondant au kid, avec cache 12 h.
	 * Sur kid inconnu, force un rafraîchissement (cas rotation de clés).
	 *
	 * @return array|WP_Error
	 */
	private function find_key( string $kid ) {
		$keys = $this->fetch_jwks( false );
		if ( is_wp_error( $keys ) ) {
			return $keys;
		}

		$match = $this->pick_key( $keys, $kid );
		if ( null === $match ) {
			$keys = $this->fetch_jwks( true );
			if ( is_wp_error( $keys ) ) {
				return $keys;
			}
			$match = $this->pick_key( $keys, $kid );
		}
		if ( null === $match ) {
			return new WP_Error( 'jwks_kid_not_found', 'aucune clé JWKS pour le kid reçu' );
		}
		return $match;
	}

	private function pick_key( array $keys, string $kid ): ?array {
		foreach ( $keys as $key ) {
			if ( ( $key['kty'] ?? '' ) !== 'RSA' ) {
				continue;
			}
			if ( '' === $kid || ( $key['kid'] ?? '' ) === $kid ) {
				return $key;
			}
		}
		return null;
	}

	/** @return array|WP_Error Liste des clés du JWKS. */
	private function fetch_jwks( bool $force_refresh ) {
		if ( ! $force_refresh ) {
			$cached = get_transient( self::JWKS_CACHE_KEY );
			if ( is_array( $cached ) ) {
				return $cached;
			}
		}

		$endpoint = (string) BConnect_Settings::get( 'jwks_endpoint' );
		if ( '' === $endpoint ) {
			return new WP_Error( 'jwks_not_configured', 'endpoint JWKS non configuré' );
		}

		$response = wp_remote_get( $endpoint, array( 'timeout' => 15 ) );
		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'jwks_unreachable', 'JWKS injoignable : ' . $response->get_error_message() );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $body ) || empty( $body['keys'] ) || ! is_array( $body['keys'] ) ) {
			return new WP_Error( 'jwks_invalid', 'réponse JWKS invalide' );
		}

		set_transient( self::JWKS_CACHE_KEY, $body['keys'], self::JWKS_CACHE_TTL );
		return $body['keys'];
	}

	/**
	 * Construit un PEM RSA public à partir des composantes n/e d'une JWK
	 * (encodage ASN.1 DER SubjectPublicKeyInfo).
	 *
	 * @return string|WP_Error
	 */
	private function jwk_to_pem( array $jwk ) {
		if ( empty( $jwk['n'] ) || empty( $jwk['e'] ) ) {
			return new WP_Error( 'jwks_invalid_key', 'clé JWKS sans modulus/exponent' );
		}

		$n = $this->b64url_decode( $jwk['n'] );
		$e = $this->b64url_decode( $jwk['e'] );

		$modulus  = $this->asn1_integer( $n );
		$exponent = $this->asn1_integer( $e );
		$rsa_key  = $this->asn1_sequence( $modulus . $exponent );
		$bit_str  = $this->asn1_tag( "\x03", "\x00" . $rsa_key );
		// OID rsaEncryption 1.2.840.113549.1.1.1 + NULL.
		$alg_id = $this->asn1_sequence( "\x06\x09\x2a\x86\x48\x86\xf7\x0d\x01\x01\x01\x05\x00" );
		$spki   = $this->asn1_sequence( $alg_id . $bit_str );

		return "-----BEGIN PUBLIC KEY-----\n" . chunk_split( base64_encode( $spki ), 64, "\n" ) . "-----END PUBLIC KEY-----\n";
	}

	private function asn1_integer( string $bytes ): string {
		// Préfixe 0x00 si le bit de poids fort est à 1 (entier non signé).
		if ( strlen( $bytes ) > 0 && ( ord( $bytes[0] ) & 0x80 ) ) {
			$bytes = "\x00" . $bytes;
		}
		return $this->asn1_tag( "\x02", $bytes );
	}

	private function asn1_sequence( string $bytes ): string {
		return $this->asn1_tag( "\x30", $bytes );
	}

	private function asn1_tag( string $tag, string $bytes ): string {
		$len = strlen( $bytes );
		if ( $len < 128 ) {
			return $tag . chr( $len ) . $bytes;
		}
		$len_bytes = ltrim( pack( 'N', $len ), "\x00" );
		return $tag . chr( 0x80 | strlen( $len_bytes ) ) . $len_bytes . $bytes;
	}

	private function b64url_decode( string $data ): string {
		$decoded = base64_decode( strtr( $data, '-_', '+/' ), true );
		return false === $decoded ? '' : $decoded;
	}
}
