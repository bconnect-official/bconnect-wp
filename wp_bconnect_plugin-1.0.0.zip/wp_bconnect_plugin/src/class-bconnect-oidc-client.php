<?php
defined( 'ABSPATH' ) || exit;

/**
 * Client OIDC Authorization Code (sans PKCE — exigence b.connect en contexte web,
 * le PKCE casse le parcours mobile cross-navigateur).
 *
 * state et nonce sont générés à chaque départ et stockés en transient 10 min,
 * avec le contexte de redirection post-login (scénario 19).
 */
class BConnect_OIDC_Client {

	const STATE_TTL = 10 * MINUTE_IN_SECONDS;

	/**
	 * Construit l'URL d'autorisation et persiste state/nonce/contexte.
	 *
	 * @param string $context       login|register|checkout|link.
	 * @param string $return_url    URL de retour post-login (validée au retour).
	 * @param int    $link_user     ID utilisateur courant pour un flow d'appairage profil.
	 * @param array  $cart_snapshot Panier invité au départ (contexte checkout uniquement),
	 *                              pour restauration si le retour b.connect atterrit dans
	 *                              un navigateur différent (bascule app bancaire mobile).
	 */
	public function build_authorize_url( string $context, string $return_url, int $link_user = 0, array $cart_snapshot = array() ): string {
		$state = wp_generate_password( 32, false );
		$nonce = wp_generate_password( 32, false );

		set_transient(
			'bconnect_state_' . $state,
			array(
				'nonce'         => $nonce,
				'context'       => $context,
				'return_url'    => $return_url,
				'link_user'     => $link_user,
				'cart_snapshot' => $cart_snapshot,
			),
			self::STATE_TTL
		);

		if ( BConnect_Settings::is_mock() ) {
			// Écran d'autorisation simulé, servi localement par le plugin.
			return add_query_arg(
				array( 'bconnect' => 'mock-authorize', 'state' => $state ),
				home_url( '/' )
			);
		}

		return add_query_arg(
			array(
				'response_type' => 'code',
				'client_id'     => rawurlencode( (string) BConnect_Settings::get( 'client_id' ) ),
				'redirect_uri'  => rawurlencode( BConnect_Settings::redirect_uri() ),
				'scope'         => rawurlencode( BConnect_Settings::scope_string() ),
				'state'         => $state,
				'nonce'         => $nonce,
			),
			(string) BConnect_Settings::get( 'authorize_endpoint' )
		);
	}

	/**
	 * Consomme (une seule fois) les données associées à un state.
	 *
	 * @return array|null
	 */
	public function consume_state( string $state ): ?array {
		if ( '' === $state || strlen( $state ) > 64 ) {
			return null;
		}
		$data = get_transient( 'bconnect_state_' . $state );
		delete_transient( 'bconnect_state_' . $state );
		return is_array( $data ) ? $data : null;
	}

	/**
	 * Échange le code d'autorisation contre les tokens (serveur → serveur,
	 * client_secret jamais exposé côté navigateur).
	 *
	 * @return array|WP_Error ['access_token','id_token',...]
	 */
	public function exchange_code( string $code ) {
		$endpoint = (string) BConnect_Settings::get( 'token_endpoint' );
		if ( '' === $endpoint ) {
			return new WP_Error( 'token_not_configured', 'token endpoint non configuré' );
		}

		$response = wp_remote_post(
			$endpoint,
			array(
				'timeout' => 15,
				'headers' => array(
					'Authorization' => 'Basic ' . base64_encode(
						BConnect_Settings::get( 'client_id' ) . ':' . BConnect_Settings::get( 'client_secret' )
					),
					'Content-Type'  => 'application/x-www-form-urlencoded',
				),
				'body'    => array(
					'grant_type'   => 'authorization_code',
					'code'         => $code,
					'redirect_uri' => BConnect_Settings::redirect_uri(),
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'token_unreachable', 'échange de code impossible : ' . $response->get_error_message() );
		}

		$status = wp_remote_retrieve_response_code( $response );
		$body   = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $status || ! is_array( $body ) || empty( $body['id_token'] ) ) {
			$error = is_array( $body ) && isset( $body['error'] ) ? sanitize_text_field( $body['error'] ) : 'reponse_invalide';
			return new WP_Error( 'token_exchange_failed', 'échange de code refusé (HTTP ' . (int) $status . ', ' . $error . ')' );
		}

		return $body;
	}
}
