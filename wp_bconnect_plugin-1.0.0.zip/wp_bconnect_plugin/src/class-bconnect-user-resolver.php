<?php
defined( 'ABSPATH' ) || exit;

/**
 * Résolution utilisateur à partir des claims b.connect validés.
 *
 * Ordre strict (BR_07) : sub d'abord, email vérifié ensuite, création en dernier.
 * Après appairage, l'email n'est plus jamais la clé (il peut changer côté
 * b.connect, scénario 12) ; un nouveau sub sur email connu = ré-appairage
 * après dissociation b.connect (scénario 13) → mise à jour sans doublon.
 *
 * Ne complète que les champs vides, n'écrase jamais une donnée existante.
 */
class BConnect_User_Resolver {

	const META_SUB               = '_bconnect_sub';
	const META_CIVILITY          = '_bconnect_civility';
	const META_BIRTHDATE         = '_bconnect_birthdate';
	const META_PHONE             = '_bconnect_phone';
	const META_POSTALADDRESS     = '_bconnect_postaladdress';

	// Metas WooCommerce natives (pas de préfixe _bconnect_ : ce sont les clés
	// que WooCommerce lit lui-même pour préremplir le formulaire de facturation).
	const META_BILLING_FIRST_NAME = 'billing_first_name';
	const META_BILLING_LAST_NAME  = 'billing_last_name';
	const META_BILLING_EMAIL      = 'billing_email';
	const META_BILLING_PHONE      = 'billing_phone';
	const META_BILLING_ADDRESS_1  = 'billing_address_1';
	const META_BILLING_ADDRESS_2  = 'billing_address_2';
	const META_BILLING_POSTCODE   = 'billing_postcode';
	const META_BILLING_CITY       = 'billing_city';
	const META_BILLING_COUNTRY    = 'billing_country';

	/**
	 * Empreinte non réversible d'un sub, pour corréler des entrées de journal
	 * sans jamais y faire apparaître l'identifiant b.connect en clair.
	 */
	private function sub_fingerprint( string $sub ): string {
		return substr( hash( 'sha256', $sub ), 0, 12 );
	}

	/**
	 * @param array $claims Claims validés.
	 * @return WP_User|WP_Error
	 */
	public function resolve( array $claims ) {
		$sub = sanitize_text_field( (string) ( $claims['sub'] ?? '' ) );
		if ( '' === $sub ) {
			return new WP_Error( 'missing_sub', 'claims sans sub' );
		}

		// A. Utilisateur déjà appairé. Complète les champs restés vides à
		// l'appairage (ex. téléphone/adresse partagés a posteriori côté
		// b.connect) — jamais d'écrasement d'une valeur déjà connue côté FS.
		$user = $this->find_by_sub( $sub );
		if ( $user ) {
			$this->fill_empty_fields( $user, $claims );
			BConnect_Logger::info( 'login_sub', 'Connexion via sub existant (user #' . $user->ID . ')' );
			return $user;
		}

		$email = sanitize_email( (string) ( $claims['email'] ?? '' ) );

		// D. Email absent : pas de création automatique (point ouvert b.connect).
		if ( '' === $email || ! is_email( $email ) ) {
			BConnect_Logger::warning( 'missing_email', 'Claims sans email exploitable, connexion refusée (sub_fp ' . $this->sub_fingerprint( $sub ) . ')' );
			return new WP_Error( 'missing_email', 'email absent des claims' );
		}

		// L'email b.connect est contractuellement vérifié ; on rejette
		// explicitement un email_verified=false si le claim est présent.
		if ( isset( $claims['email_verified'] ) && ! $claims['email_verified'] ) {
			BConnect_Logger::warning( 'email_not_verified', 'email_verified=false, appairage refusé' );
			return new WP_Error( 'email_not_verified', 'email non vérifié' );
		}

		// B. Appairage automatique par email transmis par b.connect
		// et considéré comme fiable selon la règle métier validée
		// (+ scénario 13 : mise à jour du sub).
		$user = get_user_by( 'email', $email );
		if ( $user ) {
			// Sécurité : un compte à privilèges ne peut pas être appairé ni connecté
			// sur simple correspondance d'email (l'email seul ne prouve pas la maîtrise
			// du compte WordPress). Il doit passer par l'appairage explicite depuis une
			// session déjà authentifiée. La connexion par sub déjà lié (bloc A) reste,
			// elle, autorisée.
			if ( $this->is_privileged_user( $user ) ) {
				BConnect_Logger::warning( 'privileged_link_required', 'Appairage auto par email refusé pour un compte à privilèges (user #' . $user->ID . ')' );
				return new WP_Error( 'privileged_link_required', 'compte à privilèges : appairage explicite requis' );
			}
			update_user_meta( $user->ID, self::META_SUB, $sub );
			$this->fill_empty_fields( $user, $claims );
			BConnect_Logger::info( 'paired_email', 'Appairage par email b.connect (user #' . $user->ID . ')' );
			return $user;
		}

		// C. Création automatique.
		return $this->create_user( $sub, $email, $claims );
	}

	public function find_by_sub( string $sub ): ?WP_User {
		$users = get_users(
			array(
				'meta_key'   => self::META_SUB, // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value' => $sub,           // phpcs:ignore WordPress.DB.SlowDBQuery
				'number'     => 1,
				'fields'     => 'all',
			)
		);
		return $users ? $users[0] : null;
	}

	/**
	 * Compte « à privilèges » : capacité à administrer le site, gérer les
	 * utilisateurs ou WooCommerce. Basé sur les capabilities (pas les noms de
	 * rôles) pour couvrir aussi les rôles custom. N'inclut pas l'éditeur standard.
	 */
	private function is_privileged_user( WP_User $user ): bool {
		foreach ( array( 'manage_options', 'edit_users', 'manage_woocommerce' ) as $cap ) {
			if ( user_can( $user, $cap ) ) {
				return true;
			}
		}
		return false;
	}

	/** @return WP_User|WP_Error */
	private function create_user( string $sub, string $email, array $claims ) {
		$base_login = sanitize_user( strstr( $email, '@', true ), true );
		$base_login = '' !== $base_login ? $base_login : 'bconnect_user';
		$login      = $base_login;
		$i          = 1;
		while ( username_exists( $login ) ) {
			$login = $base_login . '_' . $i++;
		}

		$user_id = wp_insert_user(
			array(
				'user_login' => $login,
				'user_email' => $email,
				// Mot de passe technique jamais communiqué : l'accès classique
				// passe par « Mot de passe oublié » (scénario 18).
				'user_pass'  => wp_generate_password( 32 ),
				'first_name' => sanitize_text_field( (string) ( $claims['given_name'] ?? '' ) ),
				'last_name'  => sanitize_text_field( (string) ( $claims['family_name'] ?? '' ) ),
				'role'       => class_exists( 'WooCommerce' ) ? 'customer' : 'subscriber',
			)
		);

		if ( is_wp_error( $user_id ) ) {
			BConnect_Logger::error( 'user_create_failed', 'Création de compte impossible : ' . $user_id->get_error_code() );
			return new WP_Error( 'user_create_failed', 'création de compte impossible' );
		}

		update_user_meta( $user_id, self::META_SUB, $sub );
		$user = get_user_by( 'id', $user_id );
		$this->fill_empty_fields( $user, $claims );

		BConnect_Logger::info( 'user_created', 'Compte créé via b.connect (user #' . $user_id . ')' );
		return $user;
	}

	/** Complète uniquement les champs vides — jamais d'écrasement. */
	public function fill_empty_fields( WP_User $user, array $claims ): void {
		$updates = array();
		if ( '' === $user->first_name && ! empty( $claims['given_name'] ) ) {
			$updates['first_name'] = sanitize_text_field( (string) $claims['given_name'] );
		}
		if ( '' === $user->last_name && ! empty( $claims['family_name'] ) ) {
			$updates['last_name'] = sanitize_text_field( (string) $claims['family_name'] );
		}
		if ( $updates ) {
			$updates['ID'] = $user->ID;
			wp_update_user( $updates );
		}

		if ( ! empty( $claims['civility'] ) && '' === (string) get_user_meta( $user->ID, self::META_CIVILITY, true ) ) {
			update_user_meta( $user->ID, self::META_CIVILITY, sanitize_text_field( (string) $claims['civility'] ) );
		}
		if ( ! empty( $claims['birthdate'] ) && '' === (string) get_user_meta( $user->ID, self::META_BIRTHDATE, true ) ) {
			update_user_meta( $user->ID, self::META_BIRTHDATE, sanitize_text_field( (string) $claims['birthdate'] ) );
		}
		if ( ! empty( $claims['phone'] ) && '' === (string) get_user_meta( $user->ID, self::META_PHONE, true ) ) {
			update_user_meta( $user->ID, self::META_PHONE, sanitize_text_field( (string) $claims['phone'] ) );
		}
		if ( ! empty( $claims['postaladdress'] ) && '' === (string) get_user_meta( $user->ID, self::META_POSTALADDRESS, true ) ) {
			// Forme du claim non confirmée par b.connect (chaîne simple ou objet structuré type claim OIDC "address") : on couvre les deux.
			$address = $claims['postaladdress'];
			$value   = is_array( $address ) ? wp_json_encode( $address ) : (string) $address;
			update_user_meta( $user->ID, self::META_POSTALADDRESS, sanitize_text_field( $value ) );
		}

		// Préremplissage du formulaire de facturation WooCommerce (jamais d'écrasement,
		// même logique que les champs ci-dessus). Sans effet si WooCommerce est absent.
		if ( class_exists( 'WooCommerce' ) ) {
			if ( ! empty( $claims['given_name'] ) && '' === (string) get_user_meta( $user->ID, self::META_BILLING_FIRST_NAME, true ) ) {
				update_user_meta( $user->ID, self::META_BILLING_FIRST_NAME, sanitize_text_field( (string) $claims['given_name'] ) );
			}
			if ( ! empty( $claims['family_name'] ) && '' === (string) get_user_meta( $user->ID, self::META_BILLING_LAST_NAME, true ) ) {
				update_user_meta( $user->ID, self::META_BILLING_LAST_NAME, sanitize_text_field( (string) $claims['family_name'] ) );
			}
			if ( is_email( $user->user_email ) && '' === (string) get_user_meta( $user->ID, self::META_BILLING_EMAIL, true ) ) {
				update_user_meta( $user->ID, self::META_BILLING_EMAIL, sanitize_email( $user->user_email ) );
			}
			if ( ! empty( $claims['phone'] ) && '' === (string) get_user_meta( $user->ID, self::META_BILLING_PHONE, true ) ) {
				update_user_meta( $user->ID, self::META_BILLING_PHONE, sanitize_text_field( (string) $claims['phone'] ) );
			}
			if ( ! empty( $claims['postaladdress'] ) && is_string( $claims['postaladdress'] ) ) {
				$this->fill_billing_address( $user, $claims['postaladdress'] );
			}
		}
	}

	/**
	 * Répartit le claim postaladdress (format confirmé : chaîne à délimiteurs `|`,
	 * "rue||code postal|ville|pays") sur les champs de facturation WooCommerce.
	 * N'écrase jamais un champ déjà rempli. Ignore silencieusement si la chaîne
	 * ne correspond pas exactement au format confirmé (mieux vaut ne rien
	 * préremplir qu'un champ mal coupé).
	 */
	private function fill_billing_address( WP_User $user, string $postaladdress ): void {
		$parts = explode( '|', $postaladdress );
		if ( 5 !== count( $parts ) ) {
			return;
		}
		list( $address_1, $address_2, $postcode, $city, $country_name ) = array_map( 'trim', $parts );

		$fields = array(
			self::META_BILLING_ADDRESS_1 => $address_1,
			self::META_BILLING_ADDRESS_2 => $address_2,
			self::META_BILLING_POSTCODE  => $postcode,
			self::META_BILLING_CITY      => $city,
		);
		foreach ( $fields as $meta_key => $value ) {
			if ( '' !== $value && '' === (string) get_user_meta( $user->ID, $meta_key, true ) ) {
				update_user_meta( $user->ID, $meta_key, sanitize_text_field( $value ) );
			}
		}

		// billing_country attend un code ISO (WooCommerce ne fait rien du nom en toutes lettres).
		if (
			'' !== $country_name
			&& '' === (string) get_user_meta( $user->ID, self::META_BILLING_COUNTRY, true )
			&& function_exists( 'WC' ) && WC()->countries
		) {
			foreach ( WC()->countries->get_countries() as $code => $name ) {
				if ( 0 === strcasecmp( $name, $country_name ) ) {
					update_user_meta( $user->ID, self::META_BILLING_COUNTRY, $code );
					break;
				}
			}
		}
	}

	/** Connexion WordPress propre. */
	public function login( WP_User $user ): void {
		wp_set_current_user( $user->ID );
		wp_set_auth_cookie( $user->ID, true );
		do_action( 'wp_login', $user->user_login, $user );
	}

	/**
	 * E. Appairage depuis un profil connecté, avec blocage strict en cas
	 * de conflit de sub (scénario 17).
	 *
	 * @return true|WP_Error
	 */
	public function link_to_user( int $user_id, array $claims ) {
		$sub = sanitize_text_field( (string) ( $claims['sub'] ?? '' ) );
		if ( '' === $sub ) {
			return new WP_Error( 'missing_sub', 'claims sans sub' );
		}

		$existing = $this->find_by_sub( $sub );
		if ( $existing && (int) $existing->ID !== $user_id ) {
			BConnect_Logger::warning( 'sub_conflict', 'Appairage bloqué : sub déjà lié à un autre compte (user #' . $existing->ID . ' vs #' . $user_id . ')' );
			return new WP_Error( 'sub_conflict', 'ce compte b.connect est déjà lié à un autre compte du site' );
		}

		update_user_meta( $user_id, self::META_SUB, $sub );
		$user = get_user_by( 'id', $user_id );
		if ( $user ) {
			$this->fill_empty_fields( $user, $claims );
		}
		BConnect_Logger::info( 'linked_profile', 'Compte lié depuis le profil (user #' . $user_id . ')' );
		return true;
	}

	/**
	 * F. Dissociation : suppression du sub uniquement. Les métas de claims
	 * (civilité, date de naissance, téléphone, adresse postale) sont conservées :
	 * elles font partie du profil de l'utilisateur sur le site (décision documentée).
	 */
	public function unlink( int $user_id ): void {
		delete_user_meta( $user_id, self::META_SUB );
		BConnect_Logger::info( 'unlinked', 'Compte dissocié de b.connect (user #' . $user_id . ')' );
	}

	public function is_linked( int $user_id ): bool {
		return '' !== (string) get_user_meta( $user_id, self::META_SUB, true );
	}
}
