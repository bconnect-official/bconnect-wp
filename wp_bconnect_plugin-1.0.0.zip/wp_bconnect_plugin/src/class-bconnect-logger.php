<?php
defined( 'ABSPATH' ) || exit;

/**
 * Journal d'événements côté admin, borné à 50 entrées.
 *
 * Règle stricte : jamais de token, secret, ni donnée personnelle complète.
 * Les entrées servent au diagnostic (scénarios 15/16/17), pas à l'audit.
 */
class BConnect_Logger {

	const OPTION_KEY  = 'bconnect_log';
	const MAX_ENTRIES = 50;

	public static function log( string $level, string $code, string $message ): void {
		$entries   = get_option( self::OPTION_KEY, array() );
		$entries   = is_array( $entries ) ? $entries : array();
		$entries[] = array(
			'time'    => time(),
			'level'   => in_array( $level, array( 'info', 'warning', 'error' ), true ) ? $level : 'info',
			'code'    => sanitize_key( $code ),
			'message' => sanitize_text_field( $message ),
		);
		if ( count( $entries ) > self::MAX_ENTRIES ) {
			$entries = array_slice( $entries, - self::MAX_ENTRIES );
		}
		update_option( self::OPTION_KEY, $entries, false );
	}

	public static function info( string $code, string $message ): void {
		self::log( 'info', $code, $message );
	}

	public static function warning( string $code, string $message ): void {
		self::log( 'warning', $code, $message );
	}

	public static function error( string $code, string $message ): void {
		self::log( 'error', $code, $message );
	}

	public static function entries(): array {
		$entries = get_option( self::OPTION_KEY, array() );
		return is_array( $entries ) ? array_reverse( $entries ) : array();
	}

	public static function clear(): void {
		delete_option( self::OPTION_KEY );
	}
}
