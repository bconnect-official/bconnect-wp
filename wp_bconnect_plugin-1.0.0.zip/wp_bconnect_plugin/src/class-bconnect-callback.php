<?php
defined( 'ABSPATH' ) || exit;

/**
 * Point d'entrée HTTP du plugin : ?bconnect=<action> sur la home.
 *
 * - callback        : retour b.connect (ou mock) — code/state ou error/state.
 * - mock-authorize  : écran d'autorisation simulé (mode mock uniquement).
 *
 * Les messages utilisateur transitent par un code whitelisté en query arg
 * (`bconnect_notice`) : jamais de texte libre venant de l'URL.
 */
class BConnect_Callback {

	const CART_RESTORE_TTL = 5 * MINUTE_IN_SECONDS;

	private static ?BConnect_Callback $instance = null;

	public static function instance(): BConnect_Callback {
		return self::$instance ??= new self();
	}

	public function register_hooks(): void {
		add_action( 'init', array( $this, 'route' ) );
		add_action( 'admin_post_bconnect_start', array( $this, 'handle_start' ) );
		add_action( 'admin_post_nopriv_bconnect_start', array( $this, 'handle_start' ) );

		// Restauration du panier invité (cf. handle_callback) : WC()->cart n'existe pas
		// encore sur le hook 'init' du callback, donc la restauration se fait sur la
		// requête suivante, une fois le panier WooCommerce chargé depuis la session.
		add_action( 'woocommerce_cart_loaded_from_session', array( $this, 'maybe_restore_pending_cart' ) );
	}

	/** Messages utilisateur, indexés par code whitelisté. */
	public static function notice_messages(): array {
		return array(
			'cancelled'      => __( 'Connexion b.connect annulée. Vous pouvez réessayer quand vous le souhaitez.', 'wp_bconnect_plugin' ),
			'unavailable'    => __( 'Le service b.connect est temporairement indisponible. Merci de réessayer dans quelques instants.', 'wp_bconnect_plugin' ),
			'auth_failed'    => __( 'La connexion via b.connect n\'a pas pu aboutir. Merci de réessayer ou d\'utiliser une connexion classique.', 'wp_bconnect_plugin' ),
			'missing_email'  => __( 'Votre compte b.connect n\'a pas transmis d\'adresse email : la création automatique de compte n\'est pas possible. Merci de créer un compte classique puis de lier b.connect depuis votre profil.', 'wp_bconnect_plugin' ),
			'privileged_link' => __( 'Ce compte WordPress doit d\'abord être lié à b.connect depuis une session WordPress existante. Connectez-vous avec votre méthode habituelle, puis utilisez « Lier mon compte b.connect ».', 'wp_bconnect_plugin' ),
			'sub_conflict'   => __( 'Ce compte b.connect est déjà lié à un autre compte sur ce site. Contactez le support si besoin.', 'wp_bconnect_plugin' ),
			'linked'         => __( 'Votre compte b.connect a bien été lié.', 'wp_bconnect_plugin' ),
			'unlinked'       => __( 'Votre compte b.connect a été dissocié. Si vous n\'avez jamais défini de mot de passe, utilisez « Mot de passe oublié » pour créer un accès classique.', 'wp_bconnect_plugin' ),
		);
	}

	/** Démarrage du flow (clic bouton) : construit l'URL authorize et redirige. */
	public function handle_start(): void {
		if ( ! BConnect_Settings::is_ready() ) {
			wp_safe_redirect( home_url( '/' ) );
			exit;
		}

		$context = isset( $_GET['context'] ) ? sanitize_key( wp_unslash( $_GET['context'] ) ) : 'login'; // phpcs:ignore WordPress.Security.NonceVerification
		if ( ! in_array( $context, array( 'login', 'register', 'checkout', 'link' ), true ) ) {
			$context = 'login';
		}

		$return_url = isset( $_GET['return'] ) ? esc_url_raw( wp_unslash( $_GET['return'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$return_url = $this->validate_return_url( $return_url, $context );

		$link_user = 0;
		if ( 'link' === $context ) {
			// L'appairage profil exige une session active et un nonce (action sensible).
			if ( ! is_user_logged_in() || ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_GET['_wpnonce'] ) ), 'bconnect_link' ) ) {
				wp_die( esc_html__( 'Action non autorisée.', 'wp_bconnect_plugin' ), '', 403 );
			}
			$link_user = get_current_user_id();
		}

		$client = new BConnect_OIDC_Client();
		// L'URL authorize est soit locale (mock), soit l'endpoint configuré : pas de wp_safe_redirect ici.
		wp_redirect( $client->build_authorize_url( $context, $return_url, $link_user, $this->snapshot_guest_cart( $context ) ) ); // phpcs:ignore WordPress.Security.SafeRedirect
		exit;
	}

	/**
	 * Panier invité au départ du flow (contexte checkout uniquement) : le retour
	 * b.connect peut atterrir dans un navigateur différent (bascule vers l'app
	 * bancaire mobile), qui n'a pas la session WooCommerce d'origine. On ne
	 * capture volontairement que product_id/variation_id/variation/quantity —
	 * jamais l'objet WC_Product (non sérialisable proprement en transient).
	 */
	private function snapshot_guest_cart( string $context ): array {
		if ( 'checkout' !== $context || is_user_logged_in() || ! function_exists( 'WC' ) ) {
			return array();
		}
		// admin-post.php s'exécute dans un contexte is_admin() : WooCommerce n'y charge
		// pas WC()->cart automatiquement (réservé au frontend/ajax) — chargement forcé.
		if ( ! WC()->cart && function_exists( 'wc_load_cart' ) ) {
			wc_load_cart();
		}
		if ( ! WC()->cart ) {
			return array();
		}
		$snapshot = array();
		foreach ( WC()->cart->get_cart() as $item ) {
			$snapshot[] = array(
				'product_id'   => (int) $item['product_id'],
				'variation_id' => (int) $item['variation_id'],
				'variation'    => (array) $item['variation'],
				'quantity'     => (int) $item['quantity'],
			);
		}
		return $snapshot;
	}

	/**
	 * Restaure, au sein de la session WooCommerce courante, le panier snapshoté
	 * avant le départ vers b.connect — appelé une fois par utilisateur connecté
	 * porteur d'un panier en attente (transient posé dans handle_callback()).
	 * Best effort : un produit devenu indisponible entre-temps est simplement
	 * ignoré par WC_Cart::add_to_cart() (retour false), sans bloquer le reste.
	 */
	public function maybe_restore_pending_cart(): void {
		if ( ! is_user_logged_in() || ! WC()->cart ) {
			return;
		}
		$key      = 'bconnect_pending_cart_' . get_current_user_id();
		$snapshot = get_transient( $key );
		if ( empty( $snapshot ) || ! is_array( $snapshot ) ) {
			return;
		}
		delete_transient( $key );

		// Réconciliation idempotente : WooCommerce conserve déjà le panier dans le
		// cas même-navigateur. On ne réinjecte donc que la quantité réellement
		// manquante par produit/variation, jamais la totalité du snapshot (sinon la
		// quantité déjà présente est doublée). Les lignes du snapshot portant le même
		// product_id/variation_id sont d'abord regroupées en une quantité cible.
		$targets = array();
		foreach ( $snapshot as $line ) {
			$product_id   = (int) ( $line['product_id'] ?? 0 );
			$variation_id = (int) ( $line['variation_id'] ?? 0 );
			if ( $product_id <= 0 ) {
				continue;
			}
			$group_key = $product_id . ':' . $variation_id;
			if ( ! isset( $targets[ $group_key ] ) ) {
				$targets[ $group_key ] = array(
					'product_id'   => $product_id,
					'variation_id' => $variation_id,
					'variation'    => (array) ( $line['variation'] ?? array() ),
					'quantity'     => 0,
				);
			}
			$targets[ $group_key ]['quantity'] += max( 0, (int) ( $line['quantity'] ?? 0 ) );
		}

		$restored = 0;
		foreach ( $targets as $target ) {
			// Quantité déjà présente pour ce produit/variation, toutes lignes de
			// panier confondues (ce que WooCommerce a déjà conservé).
			$existing_qty = 0;
			foreach ( WC()->cart->get_cart() as $item ) {
				if ( (int) $item['product_id'] === $target['product_id']
					&& (int) $item['variation_id'] === $target['variation_id'] ) {
					$existing_qty += (int) $item['quantity'];
				}
			}

			$missing = $target['quantity'] - $existing_qty;
			if ( $missing <= 0 ) {
				continue;
			}

			$added = WC()->cart->add_to_cart(
				$target['product_id'],
				$missing,
				$target['variation_id'],
				$target['variation']
			);
			if ( $added ) {
				++$restored;
			}
		}
		if ( $restored > 0 ) {
			BConnect_Logger::info( 'cart_restored', 'Panier invité complété après retour b.connect (' . $restored . '/' . count( $targets ) . ' produit(s))' );
		}
	}

	public function route(): void {
		if ( ! isset( $_GET['bconnect'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		$action = sanitize_key( wp_unslash( $_GET['bconnect'] ) ); // phpcs:ignore WordPress.Security.NonceVerification

		if ( 'mock-authorize' === $action ) {
			$this->handle_mock_authorize();
		} elseif ( 'callback' === $action ) {
			$this->handle_callback();
		}
	}

	private function handle_mock_authorize(): void {
		if ( ! BConnect_Settings::is_mock() ) {
			wp_die( esc_html__( 'Le mode mock n\'est pas activé.', 'wp_bconnect_plugin' ), '', 403 );
		}
		$state = isset( $_GET['state'] ) ? sanitize_text_field( wp_unslash( $_GET['state'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		( new BConnect_Mock_Provider() )->render_authorize_screen( $state );
	}

	private function handle_callback(): void {
		// phpcs:disable WordPress.Security.NonceVerification -- callback OIDC : la protection CSRF est le paramètre state.
		$state = isset( $_GET['state'] ) ? sanitize_text_field( wp_unslash( $_GET['state'] ) ) : '';
		$code  = isset( $_GET['code'] ) ? sanitize_text_field( wp_unslash( $_GET['code'] ) ) : '';
		$error = isset( $_GET['error'] ) ? sanitize_key( wp_unslash( $_GET['error'] ) ) : '';
		// phpcs:enable

		$client = new BConnect_OIDC_Client();
		$flow   = $client->consume_state( $state );

		if ( null === $flow ) {
			BConnect_Logger::warning( 'state_invalid', 'Callback avec state inconnu ou expiré' );
			$this->redirect_with_notice( home_url( '/' ), 'auth_failed' );
		}

		$return_url = $this->validate_return_url( (string) $flow['return_url'], (string) $flow['context'] );

		// Scénario 14 : annulation volontaire — message neutre, retour à l'origine.
		if ( 'access_denied' === $error ) {
			BConnect_Logger::info( 'user_cancelled', 'Annulation volontaire du parcours b.connect' );
			$this->redirect_with_notice( $return_url, 'cancelled' );
		}

		// Scénario 15 : erreur technique côté b.connect.
		if ( '' !== $error || '' === $code ) {
			BConnect_Logger::error( 'provider_error', 'Callback en erreur (' . ( $error ?: 'code absent' ) . ')' );
			$this->redirect_with_notice( $return_url, 'unavailable' );
		}

		$claims = $this->obtain_claims( $code, (string) $flow['nonce'] );

		if ( is_wp_error( $claims ) ) {
			// Scénario 16 : tokens reçus mais invalides — rejet silencieux,
			// log précis, message générique.
			BConnect_Logger::error( $claims->get_error_code(), 'Validation échouée : ' . $claims->get_error_message() );
			$notice = in_array( $claims->get_error_code(), array( 'token_unreachable', 'token_exchange_failed' ), true ) ? 'unavailable' : 'auth_failed';
			$this->redirect_with_notice( $return_url, $notice );
		}

		$resolver = new BConnect_User_Resolver();

		// Flow d'appairage depuis un profil connecté (scénarios 10/17).
		if ( 'link' === $flow['context'] && (int) $flow['link_user'] > 0 ) {
			$result = $resolver->link_to_user( (int) $flow['link_user'], $claims );
			$notice = is_wp_error( $result ) ? ( 'sub_conflict' === $result->get_error_code() ? 'sub_conflict' : 'auth_failed' ) : 'linked';
			$this->redirect_with_notice( $return_url, $notice );
		}

		// Flow de connexion standard (scénarios 6/7/8).
		$user = $resolver->resolve( $claims );
		if ( is_wp_error( $user ) ) {
			$notice_map = array(
				'missing_email'            => 'missing_email',
				'privileged_link_required' => 'privileged_link',
			);
			$notice = $notice_map[ $user->get_error_code() ] ?? 'auth_failed';
			$this->redirect_with_notice( $return_url, $notice );
		}

		$resolver->login( $user );

		// Panier invité à restaurer (cf. snapshot_guest_cart) : posé en transient
		// user-scopé, consommé par maybe_restore_pending_cart() sur la requête
		// suivante (WC()->cart n'est pas encore chargé ici, hook 'init').
		if ( ! empty( $flow['cart_snapshot'] ) ) {
			set_transient( 'bconnect_pending_cart_' . $user->ID, $flow['cart_snapshot'], self::CART_RESTORE_TTL );
		}

		// Succès depuis /wp-login.php : éviter de renvoyer un utilisateur
		// désormais connecté sur le formulaire de connexion.
		if ( 'login' === $flow['context'] && $this->is_login_page_url( $return_url ) ) {
			$return_url = home_url( '/' );
		}

		wp_safe_redirect( $return_url );
		exit;
	}

	/** Détecte si l'URL de retour pointe vers la page de login WordPress elle-même. */
	private function is_login_page_url( string $url ): bool {
		return wp_parse_url( $url, PHP_URL_PATH ) === wp_parse_url( wp_login_url(), PHP_URL_PATH );
	}

	/** @return array|WP_Error Claims validés (réels ou mock). */
	private function obtain_claims( string $code, string $nonce ) {
		if ( BConnect_Settings::is_mock() ) {
			return ( new BConnect_Mock_Provider() )->exchange_and_validate( $code );
		}

		if ( ! BConnect_Settings::is_configured() ) {
			return new WP_Error( 'not_configured', 'configuration OIDC incomplète, aucun appel externe effectué' );
		}

		$tokens = ( new BConnect_OIDC_Client() )->exchange_code( $code );
		if ( is_wp_error( $tokens ) ) {
			return $tokens;
		}

		return ( new BConnect_JWT_Validator() )->validate( (string) $tokens['id_token'], $nonce );
	}

	/**
	 * Valide l'URL de retour côté serveur (anti open redirect, scénario 19) :
	 * uniquement des URLs internes au site, sinon fallback selon contexte.
	 */
	private function validate_return_url( string $url, string $context ): string {
		$fallbacks = array(
			'checkout' => function_exists( 'wc_get_checkout_url' ) ? wc_get_checkout_url() : home_url( '/' ),
			'link'     => function_exists( 'wc_get_page_permalink' ) && wc_get_page_permalink( 'myaccount' ) ? wc_get_page_permalink( 'myaccount' ) : admin_url( 'profile.php' ),
			'login'    => home_url( '/' ),
			'register' => home_url( '/' ),
		);
		$fallback = $fallbacks[ $context ] ?? home_url( '/' );

		if ( '' === $url ) {
			return $fallback;
		}

		$site_host = wp_parse_url( home_url(), PHP_URL_HOST );
		$url_host  = wp_parse_url( $url, PHP_URL_HOST );
		if ( $url_host && strtolower( $url_host ) !== strtolower( (string) $site_host ) ) {
			return $fallback;
		}
		return $url;
	}

	private function redirect_with_notice( string $url, string $notice_code ): void {
		wp_safe_redirect( add_query_arg( 'bconnect_notice', $notice_code, $url ) );
		exit;
	}

	/** Message correspondant au code présent dans l'URL courante, ou chaîne vide. */
	public static function current_notice(): string {
		if ( ! isset( $_GET['bconnect_notice'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return '';
		}
		$code     = sanitize_key( wp_unslash( $_GET['bconnect_notice'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		$messages = self::notice_messages();
		return $messages[ $code ] ?? '';
	}
}
