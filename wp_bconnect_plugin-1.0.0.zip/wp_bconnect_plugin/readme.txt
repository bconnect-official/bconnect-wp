=== b.connect ===
Contributors: codeaswell
Tags: login, authentication, openid-connect, woocommerce, sso
Requires at least: 6.5
Tested up to: 7.0
Requires PHP: 8.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Authentification et création de compte via b.connect.

== Description ==

Authentification et création de compte via b.connect.

b.connect est le premier bouton d'authentification français : il permet à vos clients de se connecter ou de créer un compte sur votre boutique en un clic, sans mot de passe, en s'appuyant sur la sécurité de leur application bancaire (BNP Paribas, Crédit Agricole, Crédit Mutuel/CIC, Société Générale, LCL, Banque Populaire, Caisse d'Epargne etc.). Le service est gratuit, hébergé en France sur le cloud souverain S3NS et respecte la vie privée de vos clients : leurs données ne sont pas commercialisées.

Ce plugin couvre le périmètre V1 :

* bouton « Se connecter avec b.connect » (shortcode + affichage automatique sur les emplacements standards) ;
* connexion des utilisateurs déjà appairés ;
* appairage automatique d'un compte existant à partir de l'adresse email transmise par b.connect ;
* création automatique de compte (rôle client WooCommerce ou abonné WordPress) ;
* liaison / dissociation b.connect depuis le profil utilisateur ;
* page de configuration complète (environnement, identifiants `client_id`/`client_secret`, scopes, diagnostic de connexion et options du plugin). Les endpoints b.connect associés à l'environnement sont configurés automatiquement par le plugin.

Données traitées : le plugin reçoit de b.connect uniquement des attributs d'identité déclarative selon les scopes configurés (identifiant technique `sub`, email, prénom, nom, civilité, date de naissance, et optionnellement téléphone et adresse postale). Aucune donnée bancaire n'est reçue ni stockée. L'identifiant `sub` et les attributs sont stockés en métadonnées utilisateur WordPress. Les appels externes se limitent aux endpoints b.connect associés à l'environnement sélectionné.

== Installation ==

1. Installez et activez le plugin.
2. Rendez-vous dans Réglages → b.connect.
3. Choisissez l'environnement : Production est disponible et sélectionnée par défaut sur une nouvelle installation ; Qualification reste disponible pour les phases d'intégration et de recette.
4. Renseignez le `client_id` et le `client_secret` fournis par b.connect pour l'environnement choisi. Les endpoints associés à l'environnement sont configurés automatiquement par le plugin.
5. Déclarez la `redirect_uri` affichée dans la page de configuration auprès de b.connect.
6. Choisissez les scopes et activez l'affichage automatique si souhaité.

Sans compte b.connect, le plugin reste inactif et n'affiche aucun bouton public.

== Frequently Asked Questions ==

= Comment afficher le bouton à un emplacement précis ? =

Utilisez le shortcode `[bconnect_button]`. Attributs disponibles : `context` (`login`, `register`, `checkout`, `link`) et `variant` (`connect`, `create`). Exemple : `[bconnect_button context="checkout"]`.

= Le bouton s'affiche-t-il automatiquement ? =

Oui, si l'option « Affichage automatique » est activée : écran de connexion WordPress, formulaires de connexion/inscription et checkout WooCommerce classique.

= WooCommerce Blocks est-il pris en charge ? =

L'injection automatique n'est pas garantie sur les pages construites avec WooCommerce Blocks ni avec les builders (Elementor, Divi…). Le shortcode `[bconnect_button]` est la solution de référence dans ces contextes.

= Un utilisateur créé via b.connect a-t-il un mot de passe ? =

Un mot de passe technique est généré mais jamais communiqué. L'utilisateur peut en définir un via « Mot de passe oublié » s'il souhaite un accès classique.

== Services externes ==

Ce plugin s'appuie sur le service b.connect pour le parcours d'authentification OpenID Connect.

Lorsqu'un utilisateur choisit de se connecter ou de créer un compte via b.connect, il est redirigé vers le service b.connect pour s'authentifier. Les données correspondant aux scopes autorisés peuvent alors être retournées au site afin de créer, connecter ou compléter le compte WordPress/WooCommerce.

La fonctionnalité « En savoir plus » affiche par ailleurs un contenu distant b.connect dans une iframe, chargé depuis :
`https://www.bconnect.net/modale/fr/modale.htm`

Liens officiels b.connect :

* Conditions d'utilisation : https://www.bconnect.net/cgu/
* Politique de protection des données : https://www.bconnect.net/gdpr/

== Changelog ==

= 1.0.0 =
* Première version stable du plugin b.connect.
* Authentification et création de compte via OpenID Connect.
* Intégration WordPress et WooCommerce.
* Gestion de l'appairage et de l'enrichissement des comptes existants.
* Environnements Qualification et Production.
* Personnalisation de l'affichage du bouton b.connect.

= 0.9.0 =
* Version de recette : périmètre V1 figé pour validation. Aucun changement fonctionnel par rapport à 0.1.0.

= 0.1.0 =
* Version initiale : socle V1 complet (flow OIDC Authorization Code, page d'administration, shortcode, auto-injection, gestion des comptes).
