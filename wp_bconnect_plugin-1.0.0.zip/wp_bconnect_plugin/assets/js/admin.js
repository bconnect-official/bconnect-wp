/**
 * Boutons « Copier » de la page Réglages → b.connect.
 * Vanilla JS, sans dépendance. Aucune donnée sensible manipulée ici :
 * on copie uniquement le contenu texte d'un élément déjà présent à l'écran
 * (URL de redirection publique, shortcode).
 */
( function () {
	'use strict';

	function announce( button ) {
		var live = button.parentNode.querySelector( '.bconnect-copied' );
		if ( ! live ) {
			return;
		}
		live.textContent = button.getAttribute( 'data-copied-label' ) || 'OK';
		window.setTimeout( function () {
			live.textContent = '';
		}, 2000 );
	}

	function fallbackCopy( text, button ) {
		var area = document.createElement( 'textarea' );
		area.value = text;
		area.setAttribute( 'readonly', '' );
		area.style.position = 'absolute';
		area.style.left = '-9999px';
		document.body.appendChild( area );
		area.select();
		var succeeded = false;
		try {
			succeeded = document.execCommand( 'copy' );
		} catch ( e ) {
			/* Copie indisponible : on ne casse rien, le texte reste sélectionnable à l'écran. */
			succeeded = false;
		}
		document.body.removeChild( area );
		if ( succeeded ) {
			announce( button );
		}
	}

	function copyText( text, button ) {
		if ( navigator.clipboard && navigator.clipboard.writeText ) {
			navigator.clipboard.writeText( text ).then(
				function () {
					announce( button );
				},
				function () {
					fallbackCopy( text, button );
				}
			);
		} else {
			fallbackCopy( text, button );
		}
	}

	document.addEventListener( 'click', function ( event ) {
		var button = event.target.closest ? event.target.closest( '.bconnect-copy-btn' ) : null;
		if ( ! button ) {
			return;
		}
		event.preventDefault();
		var selector = button.getAttribute( 'data-copy-target' );
		var source = selector ? document.querySelector( selector ) : null;
		if ( ! source ) {
			return;
		}
		var text = ( source.textContent || source.value || '' ).trim();
		if ( text ) {
			copyText( text, button );
		}
	} );
}() );

/**
 * Nettoie les paramètres transitoires (`bconnect_test`, `settings-updated`) de
 * l'URL après affichage de leur notice. Les notices sont déjà rendues côté
 * serveur : on ne les masque pas, on retire seulement les paramètres pour
 * qu'ils ne réapparaissent pas à un rechargement. Tous les autres paramètres
 * (dont page=bconnect) et le fragment sont préservés, sans nouvelle entrée
 * d'historique ni rechargement.
 *
 * Le champ caché _wp_http_referer du formulaire Settings API principal est
 * généré côté serveur à partir de l'URL AVANT ce nettoyage : sans mise à jour,
 * cliquer « Enregistrer la configuration » renverrait sur l'ancienne URL et
 * réintroduirait un résultat de diagnostic périmé aux côtés du message
 * « Réglages enregistrés. ». On l'aligne donc sur l'URL nettoyée.
 */
( function () {
	'use strict';
	if ( ! window.history || ! window.history.replaceState || typeof URL !== 'function' ) {
		return;
	}
	var TRANSIENT_PARAMS = [ 'bconnect_test', 'settings-updated' ];
	try {
		var url = new URL( window.location.href );
		var changed = false;
		TRANSIENT_PARAMS.forEach( function ( param ) {
			if ( url.searchParams.has( param ) ) {
				url.searchParams.delete( param );
				changed = true;
			}
		} );
		if ( ! changed ) {
			return;
		}
		window.history.replaceState( null, '', url.toString() );

		var mainForm = document.querySelector( '.bconnect-admin form' );
		var referer = mainForm ? mainForm.querySelector( 'input[name="_wp_http_referer"]' ) : null;
		if ( referer ) {
			referer.value = url.pathname + url.search;
		}
	} catch ( e ) {
		/* URL indisponible : on ne fait rien, les notices restent simplement affichées. */
	}
}() );
