/**
 * Modale « En savoir plus » de l'écran de connexion WordPress (wp-login.php).
 * Vanilla JS, sans dépendance. Amélioration progressive : sans ce script, le
 * lien « En savoir plus » reste un lien classique ouvrant la page b.connect
 * dans un nouvel onglet. Le src de l'iframe n'est posé qu'à la première
 * ouverture, et jamais rechargé ensuite.
 */
( function () {
	'use strict';

	var trigger = document.querySelector( '[data-bconnect-modal-open]' );
	var modal   = document.querySelector( '[data-bconnect-modal]' );

	// Aucun effet si les éléments attendus ne sont pas présents.
	if ( ! trigger || ! modal ) {
		return;
	}

	var dialog   = modal.querySelector( '.bconnect-modal__dialog' );
	var iframe   = modal.querySelector( '[data-bconnect-modal-iframe]' );
	var loading  = modal.querySelector( '[data-bconnect-modal-loading]' );
	var closeBtn = modal.querySelector( '[data-bconnect-modal-close]' );
	var src      = modal.getAttribute( 'data-bconnect-modal-src' ) || '';

	if ( ! dialog || ! iframe ) {
		return;
	}

	var lastFocused = null;
	var srcLoaded   = false;

	/** Éléments focusables visibles à l'intérieur du dialogue. */
	function focusable() {
		var nodes = dialog.querySelectorAll(
			'a[href], button:not([disabled]), iframe, [tabindex]:not([tabindex="-1"])'
		);
		return Array.prototype.filter.call( nodes, function ( el ) {
			return el.offsetWidth > 0 || el.offsetHeight > 0 || el === document.activeElement;
		} );
	}

	function onKeydown( event ) {
		if ( 'Escape' === event.key || 'Esc' === event.key ) {
			event.preventDefault();
			close();
			return;
		}
		if ( 'Tab' !== event.key ) {
			return;
		}
		// Enfermement du focus au clavier dans la modale. Remarque : une fois le
		// focus entré dans l'iframe distante (cross-origin), le navigateur gère
		// seul la tabulation interne — limitation inhérente, non contournable ici.
		var items = focusable();
		if ( ! items.length ) {
			return;
		}
		var first = items[ 0 ];
		var last  = items[ items.length - 1 ];
		if ( event.shiftKey && document.activeElement === first ) {
			event.preventDefault();
			last.focus();
		} else if ( ! event.shiftKey && document.activeElement === last ) {
			event.preventDefault();
			first.focus();
		}
	}

	function onModalClick( event ) {
		// Fermeture au clic sur l'arrière-plan uniquement, jamais dans le dialogue.
		if ( event.target === modal || ( event.target.hasAttribute && event.target.hasAttribute( 'data-bconnect-modal-backdrop' ) ) ) {
			close();
		}
	}

	/** Pose le src de l'iframe une seule fois, à la première ouverture. */
	function ensureSrc() {
		if ( srcLoaded || ! src ) {
			return;
		}
		srcLoaded = true;
		if ( loading ) {
			loading.hidden = false;
		}
		// L'événement load masque l'état de chargement. Il n'est PAS une preuve
		// absolue du bon rendu distant : le lien de repli reste toujours visible.
		iframe.addEventListener( 'load', function () {
			if ( loading ) {
				loading.hidden = true;
			}
		} );
		iframe.setAttribute( 'src', src );
	}

	function open( event ) {
		if ( event ) {
			event.preventDefault();
		}
		lastFocused = document.activeElement;
		ensureSrc();
		modal.hidden = false;
		document.body.classList.add( 'bconnect-modal-open' );
		document.addEventListener( 'keydown', onKeydown, true );
		modal.addEventListener( 'click', onModalClick );
		if ( closeBtn ) {
			closeBtn.focus();
		}
	}

	function close() {
		modal.hidden = true;
		document.body.classList.remove( 'bconnect-modal-open' );
		document.removeEventListener( 'keydown', onKeydown, true );
		modal.removeEventListener( 'click', onModalClick );
		// Restauration du focus sur le lien déclencheur.
		if ( lastFocused && 'function' === typeof lastFocused.focus ) {
			lastFocused.focus();
		}
	}

	trigger.addEventListener( 'click', open );

	if ( closeBtn ) {
		closeBtn.addEventListener( 'click', function ( event ) {
			event.preventDefault();
			close();
		} );
	}
}() );
