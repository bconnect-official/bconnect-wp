<?php
/**
 * Plugin Name:       b.connect
 * Description:       Official b.connect integration for WordPress and WooCommerce: passwordless authentication with banking app.
 * Version:           1.0.5
 * Requires at least: 6.5
 * Requires PHP:      8.2
 * WC requires at least: 8.3
 * WC tested up to:   10.9
 * Author:            b.connect
 * Author URI:        https://pro.bconnect.net
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       b-connect
 */

defined( 'ABSPATH' ) || exit;

define( 'BCONNECT_VERSION', '1.0.5' );
define( 'BCONNECT_PLUGIN_FILE', __FILE__ );
define( 'BCONNECT_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'BCONNECT_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

require_once BCONNECT_PLUGIN_DIR . 'src/class-bconnect-settings.php';
require_once BCONNECT_PLUGIN_DIR . 'src/class-bconnect-logger.php';
require_once BCONNECT_PLUGIN_DIR . 'src/class-bconnect-jwt-validator.php';
require_once BCONNECT_PLUGIN_DIR . 'src/class-bconnect-oidc-client.php';
require_once BCONNECT_PLUGIN_DIR . 'src/class-bconnect-user-resolver.php';
require_once BCONNECT_PLUGIN_DIR . 'src/class-bconnect-callback.php';
require_once BCONNECT_PLUGIN_DIR . 'src/class-bconnect-button.php';
require_once BCONNECT_PLUGIN_DIR . 'src/class-bconnect-account.php';
require_once BCONNECT_PLUGIN_DIR . 'src/class-bconnect-admin.php';

register_activation_hook( __FILE__, array( 'BConnect_Settings', 'activate' ) );
register_deactivation_hook( __FILE__, 'bconnect_deactivate' );

/**
 * Nettoyage léger à la désactivation : transients de flow en cours.
 * Les options et user_meta sont conservées (voir uninstall.php).
 */
function bconnect_deactivate() {
	global $wpdb;
	$wpdb->query(
		"DELETE FROM {$wpdb->options} WHERE option_name LIKE '\_transient\_bconnect\_%' OR option_name LIKE '\_transient\_timeout\_bconnect\_%'"
	);
}

// Compatibilité WooCommerce HPOS (le plugin ne touche pas aux commandes, déclaration explicite).
add_action( 'before_woocommerce_init', function () {
	if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
	}
} );

add_action( 'plugins_loaded', 'bconnect_init' );

function bconnect_init() {
	BConnect_Callback::instance()->register_hooks();
	BConnect_Button::instance()->register_hooks();
	BConnect_Account::instance()->register_hooks();

	if ( is_admin() ) {
		BConnect_Admin::instance()->register_hooks();
	}
}
