<?php
defined( 'ABSPATH' ) || exit;

/**
 * Page d'administration : Réglages → b.connect.
 *
 * Capability manage_options + nonces Settings API. Le client_secret n'est
 * jamais ré-affiché : champ vide = conserver la valeur enregistrée.
 */
class BConnect_Admin {

	private static ?BConnect_Admin $instance = null;

	/** Suffixe de hook de l'écran Réglages → b.connect, pour cibler l'enqueue des assets. */
	private string $hook_suffix = '';

	/**
	 * URL de documentation marchand, centralisée ici. Vide tant qu'aucune URL
	 * officielle n'a été communiquée : l'interface affiche alors une mention
	 * « Documentation prochainement disponible » plutôt qu'un lien factice.
	 */
	private const DOC_URL = '';

	public static function instance(): BConnect_Admin {
		return self::$instance ??= new self();
	}

	public function register_hooks(): void {
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
		add_action( 'admin_post_bconnect_test_config', array( $this, 'handle_test_config' ) );
		add_action( 'admin_post_bconnect_clear_log', array( $this, 'handle_clear_log' ) );
	}

	public function add_menu(): void {
		$this->hook_suffix = (string) add_options_page(
			__( 'b.connect', 'b-connect' ),
			__( 'b.connect', 'b-connect' ),
			'manage_options',
			'bconnect',
			array( $this, 'render_page' )
		);
	}

	/** CSS/JS admin, chargés uniquement sur l'écran Réglages → b.connect. */
	public function enqueue_admin_assets( $hook ): void {
		if ( $hook !== $this->hook_suffix ) {
			return;
		}
		wp_enqueue_style( 'bconnect-admin', BCONNECT_PLUGIN_URL . 'assets/css/admin.css', array(), BCONNECT_VERSION );
		wp_enqueue_script( 'bconnect-admin', BCONNECT_PLUGIN_URL . 'assets/js/admin.js', array(), BCONNECT_VERSION, true );
	}

	public function register_settings(): void {
		register_setting(
			'bconnect',
			BConnect_Settings::OPTION_KEY,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( $this, 'sanitize_settings' ),
			)
		);
	}

	/** Sanitization complète du tableau d'options. */
	public function sanitize_settings( $input ): array {
		$current = BConnect_Settings::all();
		$input   = is_array( $input ) ? $input : array();
		$out     = $current;

		// Le formulaire marchand ne peut sélectionner que Qualification, ou
		// Production lorsqu'elle est disponible. Toute autre valeur — valeur inconnue
		// ou clé absente du POST — conserve l'environnement courant.
		$out['environment'] = (string) $current['environment'];
		if ( array_key_exists( 'environment', $input ) ) {
			$submitted = sanitize_key( (string) $input['environment'] );
			if ( BConnect_Settings::ENV_QUALIFICATION === $submitted ) {
				$out['environment'] = BConnect_Settings::ENV_QUALIFICATION;
			} elseif ( BConnect_Settings::ENV_PRODUCTION === $submitted ) {
				// Production reste refusée côté serveur tant que ses endpoints
				// officiels ne sont pas fournis, quelle que soit la manipulation.
				if ( BConnect_Settings::environment_available( BConnect_Settings::ENV_PRODUCTION ) ) {
					$out['environment'] = BConnect_Settings::ENV_PRODUCTION;
				} else {
					add_settings_error(
						BConnect_Settings::OPTION_KEY,
						'bconnect_production_unavailable',
						__( 'L\'environnement Production n\'est pas encore disponible : les paramètres officiels b.connect n\'ont pas encore été communiqués. L\'environnement précédent a été conservé.', 'b-connect' ),
						'error'
					);
				}
			}
			// Valeur inconnue : ignorée, l'environnement courant est conservé.
		}

		$out['client_id'] = sanitize_text_field( $input['client_id'] ?? '' );

		// Secret : champ laissé vide = on conserve l'existant.
		$secret = trim( (string) ( $input['client_secret'] ?? '' ) );
		if ( '' !== $secret ) {
			$out['client_secret'] = $secret;
		}

		// Endpoints OIDC : plus jamais saisis par le marchand, sélectionnés par
		// environnement via BConnect_Settings::endpoint_map(). Les anciennes clés
		// éventuellement encore en base sont laissées telles quelles (ignorées).

		$catalog    = BConnect_Settings::scope_catalog();
		$restricted = in_array( $out['environment'], array( BConnect_Settings::ENV_QUALIFICATION, BConnect_Settings::ENV_PRODUCTION ), true )
			? BConnect_Settings::restricted_scopes()
			: array();
		$scopes     = array( 'openid', 'email' );
		foreach ( (array) ( $input['scopes'] ?? array() ) as $scope ) {
			$scope = sanitize_key( $scope );
			// Rejeté même sur un POST forgé : civility/birthdate ne peuvent pas être
			// enregistrés en qualification ni en production.
			if ( isset( $catalog[ $scope ] ) && ! in_array( $scope, $restricted, true ) ) {
				$scopes[] = $scope;
			}
		}
		$out['scopes'] = array_values( array_unique( $scopes ) );

		$out['auto_display']        = ! empty( $input['auto_display'] );
		$out['delete_on_uninstall'] = ! empty( $input['delete_on_uninstall'] );

		$align                = sanitize_key( (string) ( $input['button_align'] ?? 'left' ) );
		$out['button_align']  = array_key_exists( $align, BConnect_Settings::button_align_choices() ) ? $align : 'left';

		$theme                = sanitize_key( (string) ( $input['button_theme'] ?? 'blue' ) );
		$out['button_theme']  = array_key_exists( $theme, BConnect_Settings::button_theme_choices() ) ? $theme : 'blue';

		// aud_mode / aud_custom ne sont plus lus depuis le formulaire : l'audience
		// attendue est dérivée de l'environnement (config interne) ou du client_id.

		// Rafraîchit le cache JWKS sur un changement effectif d'environnement
		// (les endpoints effectifs en dépendent désormais).
		if ( $out['environment'] !== $current['environment'] ) {
			delete_transient( BConnect_JWT_Validator::JWKS_CACHE_KEY );
		}

		return $out;
	}

	public function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s      = BConnect_Settings::all();
		$status = BConnect_Settings::status();
		$opt    = BConnect_Settings::OPTION_KEY;

		$status_labels = array(
			'non_configure'                      => __( 'Non configuré', 'b-connect' ),
			BConnect_Settings::ENV_QUALIFICATION => __( 'Qualification', 'b-connect' ),
			BConnect_Settings::ENV_PRODUCTION    => __( 'Production', 'b-connect' ),
		);

		$env_active       = BConnect_Settings::environment();
		$env_active_label = $status_labels[ $env_active ] ?? __( 'Non défini', 'b-connect' );
		$copied_label     = __( 'Copié !', 'b-connect' );

		// Libellé de statut destiné au marchand (distinct de l'environnement affiché
		// séparément) : Configuré / Non configuré. Dérivé de status(), sans en
		// modifier la logique.
		if ( 'non_configure' === $status ) {
			$status_display = __( 'Non configuré', 'b-connect' );
		} else {
			$status_display = __( 'Configuré', 'b-connect' );
		}
		?>
		<div class="wrap bconnect-admin">
			<h1><?php esc_html_e( 'b.connect — Configuration', 'b-connect' ); ?></h1>

			<?php if ( isset( $_GET['bconnect_test'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification ?>
				<?php $ok = 'ok' === sanitize_key( wp_unslash( $_GET['bconnect_test'] ) ); // phpcs:ignore WordPress.Security.NonceVerification ?>
				<div class="notice <?php echo $ok ? 'notice-success' : 'notice-error'; ?> is-dismissible"><p>
					<?php echo $ok ? esc_html__( 'Vérification des services b.connect : les services répondent.', 'b-connect' ) : esc_html__( 'Vérification des services b.connect : au moins un service est injoignable ou invalide. Voir le journal technique ci-dessous.', 'b-connect' ); ?>
				</p></div>
			<?php endif; ?>

			<!-- Carte de synthèse : statut, environnement actif, URL de redirection. -->
			<div class="bconnect-card">
				<h2><?php esc_html_e( 'État de la configuration', 'b-connect' ); ?></h2>
				<table class="bconnect-status-table">
					<tbody>
						<tr>
							<th scope="row"><?php esc_html_e( 'Statut', 'b-connect' ); ?></th>
							<td><?php echo esc_html( $status_display ); ?></td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Environnement actif', 'b-connect' ); ?></th>
							<td><?php echo esc_html( $env_active_label ); ?></td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'URL de redirection', 'b-connect' ); ?></th>
							<td>
								<span class="bconnect-copy-row">
									<code id="bconnect-redirect-uri" class="bconnect-code"><?php echo esc_html( BConnect_Settings::redirect_uri() ); ?></code>
									<button type="button" class="button bconnect-copy-btn" data-copy-target="#bconnect-redirect-uri" data-copied-label="<?php echo esc_attr( $copied_label ); ?>">
										<?php esc_html_e( 'Copier', 'b-connect' ); ?>
									</button>
									<span class="bconnect-copied" role="status" aria-live="polite"></span>
								</span>
								<p class="description"><?php esc_html_e( 'À communiquer à b.connect pour déclaration.', 'b-connect' ); ?></p>
							</td>
						</tr>
					</tbody>
				</table>
			</div>

			<?php if ( 'non_configure' === $status ) :
				// On se base uniquement sur ce que le marchand saisit (client_id /
				// client_secret), jamais sur les endpoints internes. « requise » =
				// les deux absents ; « incomplète » = un seul présent, ou config
				// marchande encore insuffisante (ex. environnement indisponible).
				$has_client_id     = '' !== trim( (string) $s['client_id'] );
				$has_client_secret = '' !== trim( (string) $s['client_secret'] );
				$partially_filled  = $has_client_id || $has_client_secret;
				?>
				<div class="notice notice-warning inline">
					<p>
						<strong>
							<?php
							echo $partially_filled
								? esc_html__( 'Configuration incomplète', 'b-connect' )
								: esc_html__( 'Configuration requise', 'b-connect' );
							?>
						</strong>
					</p>
					<?php if ( $partially_filled ) : ?>
						<p><?php esc_html_e( 'Certains identifiants ont déjà été renseignés, mais la configuration n\'est pas encore complète. Complétez les champs restants ci-dessous pour activer b.connect sur votre site.', 'b-connect' ); ?></p>
					<?php else : ?>
						<p><?php esc_html_e( 'Pour activer b.connect sur votre site, renseignez ci-dessous les identifiants fournis lors de votre onboarding b.connect.', 'b-connect' ); ?></p>
						<p><?php esc_html_e( 'Vous ne disposez pas encore d\'identifiants b.connect ? Contactez b.connect pour démarrer votre onboarding.', 'b-connect' ); ?></p>
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<form method="post" action="options.php">
				<?php settings_fields( 'bconnect' ); ?>

				<!-- Carte « Connexion à b.connect » : environnement + identifiants. -->
				<div class="bconnect-card">
					<h2><?php esc_html_e( 'Connexion à b.connect', 'b-connect' ); ?></h2>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><?php esc_html_e( 'Environnement', 'b-connect' ); ?></th>
							<td>
								<?php
								$envs = array(
									BConnect_Settings::ENV_QUALIFICATION => __( 'Qualification', 'b-connect' ),
									BConnect_Settings::ENV_PRODUCTION    => __( 'Production', 'b-connect' ),
								);
								foreach ( $envs as $value => $label ) :
									$available = BConnect_Settings::environment_available( $value );
									?>
									<label class="bconnect-option<?php echo $available ? '' : ' bconnect-env-disabled'; ?>">
										<input type="radio" name="<?php echo esc_attr( $opt ); ?>[environment]" value="<?php echo esc_attr( $value ); ?>" <?php checked( $s['environment'], $value ); ?> <?php disabled( ! $available ); ?> />
										<?php echo esc_html( $label ); ?>
										<?php if ( ! $available ) : ?>
											<em>— <?php esc_html_e( 'disponible après communication des paramètres officiels b.connect', 'b-connect' ); ?></em>
										<?php endif; ?>
									</label>
								<?php endforeach; ?>
								<p class="description"><?php esc_html_e( 'Les services b.connect sont sélectionnés automatiquement selon l\'environnement ; aucune URL n\'est à saisir.', 'b-connect' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="bconnect_client_id"><?php esc_html_e( 'client_id', 'b-connect' ); ?></label></th>
							<td><input type="text" id="bconnect_client_id" class="regular-text" name="<?php echo esc_attr( $opt ); ?>[client_id]" value="<?php echo esc_attr( $s['client_id'] ); ?>" autocomplete="off" /></td>
						</tr>
						<tr>
							<th scope="row"><label for="bconnect_client_secret"><?php esc_html_e( 'client_secret', 'b-connect' ); ?></label></th>
							<td>
								<input type="password" id="bconnect_client_secret" class="regular-text" name="<?php echo esc_attr( $opt ); ?>[client_secret]" value="" autocomplete="new-password"
									placeholder="<?php echo '' !== $s['client_secret'] ? esc_attr__( '•••••••• (enregistré — laisser vide pour conserver)', 'b-connect' ) : esc_attr__( 'Non renseigné', 'b-connect' ); ?>" />
								<p class="description"><?php esc_html_e( 'Laisser vide pour conserver le secret déjà enregistré. Jamais ré-affiché après enregistrement, utilisé uniquement côté serveur.', 'b-connect' ); ?></p>
							</td>
						</tr>
					</table>
				</div>

				<!-- Carte « Données demandées » : scopes. -->
				<div class="bconnect-card">
					<h2><?php esc_html_e( 'Données demandées', 'b-connect' ); ?></h2>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><?php esc_html_e( 'Scopes', 'b-connect' ); ?></th>
							<td>
								<?php
								$restricted_scopes = in_array( $s['environment'], array( BConnect_Settings::ENV_QUALIFICATION, BConnect_Settings::ENV_PRODUCTION ), true )
									? BConnect_Settings::restricted_scopes()
									: array();
								foreach ( BConnect_Settings::scope_catalog() as $slug => list( $label, $locked ) ) :
									$restricted = in_array( $slug, $restricted_scopes, true );
									?>
									<label class="bconnect-option">
										<input type="checkbox" name="<?php echo esc_attr( $opt ); ?>[scopes][]" value="<?php echo esc_attr( $slug ); ?>"
											<?php checked( ( in_array( $slug, (array) $s['scopes'], true ) || $locked ) && ! $restricted ); ?>
											<?php disabled( $locked || $restricted ); ?> />
										<?php echo esc_html( $label ); ?>
										<?php if ( $locked ) : ?>
											<span class="bconnect-badge bconnect-badge-required"><?php esc_html_e( 'obligatoire', 'b-connect' ); ?></span>
										<?php elseif ( $restricted ) : ?>
											<span class="bconnect-badge bconnect-badge-restricted"><?php esc_html_e( 'indisponible pour le moment', 'b-connect' ); ?></span>
										<?php else : ?>
											<span class="bconnect-badge bconnect-badge-optional"><?php esc_html_e( 'optionnel', 'b-connect' ); ?></span>
										<?php endif; ?>
									</label>
								<?php endforeach; ?>
								<?php if ( $restricted_scopes ) : ?>
									<p class="description"><?php esc_html_e( 'civility et birthdate sont temporairement indisponibles.', 'b-connect' ); ?></p>
								<?php endif; ?>
							</td>
						</tr>
					</table>
				</div>

				<!-- Carte « Affichage du bouton » : auto-injection, placement manuel, documentation. -->
				<div class="bconnect-card">
					<h2><?php esc_html_e( 'Affichage du bouton', 'b-connect' ); ?></h2>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><?php esc_html_e( 'Affichage automatique', 'b-connect' ); ?></th>
							<td>
								<label>
									<input type="checkbox" name="<?php echo esc_attr( $opt ); ?>[auto_display]" value="1" <?php checked( $s['auto_display'] ); ?> />
									<?php esc_html_e( 'Afficher automatiquement le bouton sur les emplacements standards (login WordPress, Mon compte et checkout WooCommerce classique)', 'b-connect' ); ?>
								</label>
								<p class="description"><?php esc_html_e( 'Pour les thèmes custom, builders et WooCommerce Blocks, utilisez le shortcode [bconnect_button].', 'b-connect' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Thème du bouton', 'b-connect' ); ?></th>
							<td>
								<?php foreach ( BConnect_Settings::button_theme_choices() as $value => $label ) : ?>
									<label class="bconnect-theme-option">
										<input type="radio" name="<?php echo esc_attr( $opt ); ?>[button_theme]" value="<?php echo esc_attr( $value ); ?>" <?php checked( $s['button_theme'], $value ); ?> />
										<span class="bconnect-theme-preview-box">
											<img class="bconnect-theme-preview" src="<?php echo esc_url( BCONNECT_PLUGIN_URL . 'assets/img/bconnect_largebutton_connect_' . $value . '.svg' ); ?>" alt="" />
										</span>
										<?php echo esc_html( $label ); ?>
									</label>
								<?php endforeach; ?>
								<p class="description"><?php esc_html_e( 'S\'applique aux boutons de connexion et de création de compte. Le bouton de liaison depuis un profil déjà connecté reste en bleu, seule variante disponible pour ce contexte.', 'b-connect' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Alignement du bouton (shortcode)', 'b-connect' ); ?></th>
							<td>
								<?php foreach ( BConnect_Settings::button_align_choices() as $value => $label ) : ?>
									<label class="bconnect-option">
										<input type="radio" name="<?php echo esc_attr( $opt ); ?>[button_align]" value="<?php echo esc_attr( $value ); ?>" <?php checked( $s['button_align'], $value ); ?> />
										<?php echo esc_html( $label ); ?>
									</label>
								<?php endforeach; ?>
								<p class="description"><?php esc_html_e( 'S\'applique uniquement au bouton placé via le shortcode [bconnect_button]. Le bouton affiché automatiquement (login, Mon compte, checkout) reste centré.', 'b-connect' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Placement manuel du bouton', 'b-connect' ); ?></th>
							<td>
								<p><?php esc_html_e( 'Vous pouvez afficher le bouton b.connect dans une page, un article ou un builder compatible avec les shortcodes en utilisant :', 'b-connect' ); ?></p>
								<span class="bconnect-copy-row">
									<code id="bconnect-shortcode" class="bconnect-code">[bconnect_button]</code>
									<button type="button" class="button bconnect-copy-btn" data-copy-target="#bconnect-shortcode" data-copied-label="<?php echo esc_attr( $copied_label ); ?>">
										<?php esc_html_e( 'Copier', 'b-connect' ); ?>
									</button>
									<span class="bconnect-copied" role="status" aria-live="polite"></span>
								</span>
								<p><?php esc_html_e( 'Dans votre éditeur de page ou votre builder, ajoutez un bloc ou un module compatible avec les shortcodes, puis collez ce code.', 'b-connect' ); ?></p>
								<p class="description"><?php esc_html_e( 'Ce mode est recommandé pour les pages personnalisées, WooCommerce Blocks ou les thèmes qui ne proposent pas d\'emplacement automatique fiable.', 'b-connect' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Documentation', 'b-connect' ); ?></th>
							<td>
								<?php if ( '' !== self::DOC_URL ) : ?>
									<a class="button" href="<?php echo esc_url( self::DOC_URL ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Consulter la documentation', 'b-connect' ); ?></a>
								<?php else : ?>
									<p class="description"><?php esc_html_e( 'Documentation prochainement disponible.', 'b-connect' ); ?></p>
								<?php endif; ?>
							</td>
						</tr>
					</table>
				</div>

				<!-- Réglages avancés : repliés par défaut, ouverts si l'option destructive est déjà active. -->
				<?php if ( $s['delete_on_uninstall'] ) : ?>
				<details class="bconnect-card bconnect-advanced" open>
				<?php else : ?>
				<details class="bconnect-card bconnect-advanced">
				<?php endif; ?>
					<summary><?php esc_html_e( 'Réglages avancés', 'b-connect' ); ?></summary>
					<h3><?php esc_html_e( 'Désinstallation et données', 'b-connect' ); ?></h3>
					<p class="description bconnect-warning"><?php esc_html_e( 'Option destructive : à la désinstallation du plugin, les appairages et métadonnées b.connect des utilisateurs seront définitivement supprimés. Laissez décoché pour les conserver en cas de réinstallation.', 'b-connect' ); ?></p>
					<label>
						<input type="checkbox" name="<?php echo esc_attr( $opt ); ?>[delete_on_uninstall]" value="1" <?php checked( $s['delete_on_uninstall'] ); ?> />
						<?php esc_html_e( 'À la désinstallation du plugin, supprimer aussi les appairages (_bconnect_sub) et métadonnées utilisateur b.connect', 'b-connect' ); ?>
					</label>
				</details>

				<?php submit_button( __( 'Enregistrer la configuration', 'b-connect' ) ); ?>
			</form>

			<!-- Carte « Diagnostic » : hors du formulaire principal. -->
			<div class="bconnect-card">
				<h2><?php esc_html_e( 'Diagnostic', 'b-connect' ); ?></h2>
				<p><?php esc_html_e( 'Ce contrôle vérifie la disponibilité technique des services b.connect configurés. Il ne remplace pas un parcours complet de connexion.', 'b-connect' ); ?></p>
				<p>
					<a class="button" href="<?php echo esc_url( wp_nonce_url( add_query_arg( 'action', 'bconnect_test_config', admin_url( 'admin-post.php' ) ), 'bconnect_test_config' ) ); ?>">
						<?php esc_html_e( 'Vérifier l\'accès aux services b.connect', 'b-connect' ); ?>
					</a>
				</p>
			</div>

			<!-- Journal technique : replié par défaut, hauteur limitée + scroll interne. -->
			<?php $entries = BConnect_Logger::entries(); ?>
			<details class="bconnect-card">
				<summary>
					<?php
					/* translators: %d = nombre d'entrées du journal. */
					printf( esc_html__( 'Journal technique (%d)', 'b-connect' ), count( $entries ) );
					?>
				</summary>
				<?php if ( ! $entries ) : ?>
					<p><?php esc_html_e( 'Aucun événement enregistré.', 'b-connect' ); ?></p>
				<?php else : ?>
					<div class="bconnect-journal-scroll">
						<table class="widefat striped">
							<thead><tr>
								<th><?php esc_html_e( 'Date', 'b-connect' ); ?></th>
								<th><?php esc_html_e( 'Niveau', 'b-connect' ); ?></th>
								<th><?php esc_html_e( 'Code', 'b-connect' ); ?></th>
								<th><?php esc_html_e( 'Message', 'b-connect' ); ?></th>
							</tr></thead>
							<tbody>
							<?php foreach ( $entries as $entry ) : ?>
								<tr>
									<td><?php echo esc_html( wp_date( 'Y-m-d H:i:s', $entry['time'] ) ); ?></td>
									<td><?php echo esc_html( $entry['level'] ); ?></td>
									<td><code><?php echo esc_html( $entry['code'] ); ?></code></td>
									<td><?php echo esc_html( $entry['message'] ); ?></td>
								</tr>
							<?php endforeach; ?>
							</tbody>
						</table>
					</div>
					<p>
						<a class="button" href="<?php echo esc_url( wp_nonce_url( add_query_arg( 'action', 'bconnect_clear_log', admin_url( 'admin-post.php' ) ), 'bconnect_clear_log' ) ); ?>">
							<?php esc_html_e( 'Vider le journal', 'b-connect' ); ?>
						</a>
					</p>
				<?php endif; ?>
			</details>
		</div>
		<?php
	}

	/** Scénario 20 : vérification de joignabilité des endpoints configurés. */
	public function handle_test_config(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Action non autorisée.', 'b-connect' ), '', 403 );
		}
		check_admin_referer( 'bconnect_test_config' );

		$ok = true;

		if ( ! BConnect_Settings::is_configured() ) {
			$ok = false;
			BConnect_Logger::warning( 'test_config', 'Configuration incomplète : test impossible.' );
		} else {
			foreach ( array( 'authorize_endpoint', 'token_endpoint', 'jwks_endpoint' ) as $key ) {
				$url      = (string) BConnect_Settings::get( $key );
				$response = wp_remote_get( $url, array( 'timeout' => 10, 'redirection' => 0 ) );
				if ( is_wp_error( $response ) ) {
					$ok = false;
					BConnect_Logger::error( 'test_config', $key . ' injoignable : ' . $response->get_error_message() );
				} else {
					$code = wp_remote_retrieve_response_code( $response );
					// Un endpoint OIDC vivant répond, y compris en 4xx sur une requête nue ; seuls les 5xx signalent un vrai problème.
					if ( $code >= 500 ) {
						$ok = false;
						BConnect_Logger::error( 'test_config', $key . ' répond en erreur serveur (HTTP ' . (int) $code . ')' );
					} else {
						BConnect_Logger::info( 'test_config', $key . ' joignable (HTTP ' . (int) $code . ')' );
					}
				}
			}
		}

		wp_safe_redirect( add_query_arg( array( 'page' => 'bconnect', 'bconnect_test' => $ok ? 'ok' : 'ko' ), admin_url( 'options-general.php' ) ) );
		exit;
	}

	public function handle_clear_log(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Action non autorisée.', 'b-connect' ), '', 403 );
		}
		check_admin_referer( 'bconnect_clear_log' );
		BConnect_Logger::clear();
		wp_safe_redirect( add_query_arg( 'page', 'bconnect', admin_url( 'options-general.php' ) ) );
		exit;
	}
}
