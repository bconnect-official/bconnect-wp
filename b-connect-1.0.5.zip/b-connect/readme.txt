=== b.connect ===
Contributors: bconnectnet
Tags: login, authentication, openid-connect, woocommerce, sso
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 8.2
Stable tag: 1.0.5
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Official b.connect integration for WordPress and WooCommerce: passwordless sign-in and account creation with banking app.

== Description ==

Official WordPress and WooCommerce integration for the b.connect passwordless authentication solution. The b.connect button enables your users to easily log in or create an account on your applications: in one click in more than 80% of cases and in the remaining 20% by relying on the security of their banking app (BNP Paribas, Crédit Agricole, Crédit Mutuel/CIC, Société Générale, LCL, Banque Populaire, Caisse d'Epargne, etc.). The service is free for your users, hosted in France on the S3NS sovereign cloud, and respects their privacy: their data is not sold.

This plugin covers the V1 scope:

* "Log in with b.connect" button (shortcode + automatic display in the standard locations);
* login for users who are already paired;
* automatic pairing of an existing account based on the email address provided by b.connect;
* automatic account creation (WooCommerce customer role or WordPress subscriber);
* b.connect linking / unlinking from the user profile;
* full configuration page (environment, `client_id`/`client_secret` credentials, scopes, connection diagnostics and plugin options). The b.connect endpoints for the environment are configured automatically by the plugin.

Data processed: the plugin receives from b.connect only declarative identity attributes according to the configured scopes (technical identifier `sub`, email, first name, last name, salutation, date of birth, and optionally phone and postal address). No banking data is received or stored. The `sub` identifier and the attributes are stored as WordPress user metadata. External calls are limited to the b.connect endpoints for the selected environment.

== Installation ==

1. Install and activate the plugin.
2. Go to Settings → b.connect.
3. Choose the environment: Production is available and selected by default on a new installation; Qualification remains available for integration and acceptance-testing phases.
4. Enter the `client_id` and `client_secret` provided by b.connect for the chosen environment. The endpoints for the environment are configured automatically by the plugin.
5. Declare the `redirect_uri` shown on the configuration page with b.connect.
6. Choose the scopes and enable automatic display if desired.

Without a b.connect account, the plugin stays inactive and displays no public button.

== Frequently Asked Questions ==

= How do I display the button at a specific location? =

Use the `[bconnect_button]` shortcode. Available attributes: `context` (`login`, `register`, `checkout`, `link`) and `variant` (`connect`, `create`). Example: `[bconnect_button context="checkout"]`.

= Does the button display automatically? =

Yes, if the "Automatic display" option is enabled: WordPress login screen, login/registration forms and the classic WooCommerce checkout.

= Is WooCommerce Blocks supported? =

Automatic injection is not guaranteed on pages built with WooCommerce Blocks or with page builders (Elementor, Divi, etc.). The `[bconnect_button]` shortcode is the recommended solution in those contexts.

= Does a user created via b.connect have a password? =

A technical password is generated but never shared. The user can set one via "Lost your password?" if they want classic access.

== External services ==

This plugin relies on the b.connect service for the OpenID Connect "Authorization Code" authentication flow. Contacting b.connect is required for the plugin's single purpose: letting a user log in, create an account, or link an existing account via b.connect.

Two environments exist, both operated by b.connect; only the one selected in the plugin settings is contacted:

* Production: `bconnect.net`, `api.bconnect.net`
* Qualification: `bconnect-qualif.net`, `api.bconnect-qualif.net` — this is b.connect's integration / acceptance-testing (qualification) environment.

When this happens and what is sent:

During login / account creation / linking: when the user clicks the b.connect button, their browser is redirected to the authorize endpoint (`bconnect.net` or `bconnect-qualif.net`) with the following parameters: `client_id`, `redirect_uri`, the requested scopes, `state` and `nonce`. No existing WordPress/WooCommerce user data is sent to b.connect at this step.

Code exchange: after the user has authenticated with b.connect, the site performs a server-to-server call to the token endpoint (`api.bconnect.net` or `api.bconnect-qualif.net`). It sends the authorization code and authenticates itself with its `client_id` / `client_secret`. The signature of the returned `id_token` is then verified against the JWKS endpoint of the same environment.

Data received: only the declarative identity claims corresponding to the authorized scopes are received: `sub` (technical identifier), email, `given_name`, `family_name`, `civility`, `birthdate`, and optionally phone and postal address. No banking data is ever received or stored.

Admin diagnostic: from the plugin settings page, an administrator can click a "Check access to b.connect services" button. This performs a server-side reachability check — a bare GET request carrying no WordPress/WooCommerce or user data — against the authorize, token and JWKS endpoints of the currently selected environment (the same hosts listed above). It is triggered only by an explicit administrator action.

The "Learn more" feature additionally displays remote b.connect content, loaded in an information iframe on the browser side from:
`https://www.bconnect.net/modale/fr/modale.htm`

Official b.connect links:

* Terms of use: https://www.bconnect.net/cgu/
* Data protection policy: https://www.bconnect.net/gdpr/

== Changelog ==

= 1.0.5 =
* Removed the development mock infrastructure from the distributed plugin.
* Expanded the documentation of the b.connect external services.
* Documented the administration diagnostic for external service checks.
* Updated the public WordPress.org descriptions.

= 1.0.4 =
* WordPress.org compliance updates.
* Updated the plugin text domain to match the WordPress.org slug.
* Updated the readme to use English as the base language.

= 1.0.3 =
* WordPress.org metadata adjustments.
* Description update.
* Compatibility validated with WordPress 7.1.

= 1.0.2 =
* Fixed the WordPress.org contributor identifier (bconnectnet).

= 1.0.1 =
* Fixed the b.connect button display on Firefox on the WordPress login screen (wp-login.php).
* Added the intro text and the "Learn more" modal on the WooCommerce "My Account" page for logged-out visitors.

= 1.0.0 =
* First stable version of the b.connect plugin.
* Authentication and account creation via OpenID Connect.
* WordPress and WooCommerce integration.
* Pairing and enrichment of existing accounts.
* Qualification and Production environments.
* Customization of the b.connect button display.

= 0.9.0 =
* Acceptance-testing version: V1 scope frozen for validation. No functional change compared to 0.1.0.

= 0.1.0 =
* Initial version: complete V1 foundation (OIDC Authorization Code flow, administration page, shortcode, auto-injection, account management).
