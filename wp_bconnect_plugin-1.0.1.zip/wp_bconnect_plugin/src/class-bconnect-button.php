<?php
defined( 'ABSPATH' ) || exit;

/**
 * Bouton b.connect : shortcode universel + auto-injection sur hooks standards.
 *
 * Le shortcode [bconnect_button] est la référence pour tous les contextes
 * non standards (builders, thèmes custom, WooCommerce Blocks). L'injection
 * automatique se limite aux hooks standards WordPress / WooCommerce classique.
 */
class BConnect_Button {

	private static ?BConnect_Button $instance = null;

	public static function instance(): BConnect_Button {
		return self::$instance ??= new self();
	}

	public function register_hooks(): void {
		add_shortcode( 'bconnect_button', array( $this, 'shortcode' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'login_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );

		// JS de la modale « En savoir plus » : écran de connexion WordPress…
		add_action( 'login_enqueue_scripts', array( $this, 'enqueue_login_assets' ) );
		// …et front WooCommerce « Mon compte » déconnecté, où le bloc peut aussi s'afficher.
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_account_assets' ) );

		// Affichage des notices de retour de flow.
		add_filter( 'login_message', array( $this, 'login_notice' ) );
		add_action( 'wp_body_open', array( $this, 'front_notice' ) );

		if ( ! BConnect_Settings::get( 'auto_display' ) ) {
			return;
		}

		// WordPress standard.
		add_action( 'login_form', array( $this, 'render_login' ) );
		add_action( 'register_form', array( $this, 'render_register' ) );

		// WooCommerce classique (pas de garantie WooCommerce Blocks — documenté).
		add_action( 'woocommerce_before_customer_login_form', array( $this, 'render_login' ) );
		add_action( 'woocommerce_before_checkout_form', array( $this, 'render_checkout' ), 5 );
	}

	public function enqueue_assets(): void {
		wp_enqueue_style( 'bconnect', BCONNECT_PLUGIN_URL . 'assets/css/bconnect.css', array(), BCONNECT_VERSION );
	}

	/**
	 * Script vanilla de la modale « En savoir plus », chargé uniquement sur
	 * wp-login.php et seulement quand le bloc intro peut réellement s'afficher
	 * (plugin prêt + affichage auto). Aucun impact sur le front ni l'admin.
	 */
	public function enqueue_login_assets(): void {
		if ( ! BConnect_Settings::get( 'auto_display' ) || ! BConnect_Settings::is_ready() ) {
			return;
		}
		wp_enqueue_script( 'bconnect-login-modal', BCONNECT_PLUGIN_URL . 'assets/js/login-modal.js', array(), BCONNECT_VERSION, true );
	}

	/**
	 * Même script de modale sur le front, mais strictement limité à la page
	 * WooCommerce « Mon compte » d'un visiteur déconnecté — seul emplacement
	 * front où le bloc d'accompagnement (et donc la modale) est rendu. Mêmes
	 * handle et fichier que sur wp-login.php ; jamais chargé ailleurs sur le front.
	 */
	public function enqueue_account_assets(): void {
		if ( ! function_exists( 'is_account_page' ) || ! is_account_page() || is_user_logged_in() ) {
			return;
		}
		if ( ! BConnect_Settings::get( 'auto_display' ) || ! BConnect_Settings::is_ready() ) {
			return;
		}
		wp_enqueue_script( 'bconnect-login-modal', BCONNECT_PLUGIN_URL . 'assets/js/login-modal.js', array(), BCONNECT_VERSION, true );
	}

	public function shortcode( $atts ): string {
		$context_given = is_array( $atts ) && isset( $atts['context'] );

		$atts = shortcode_atts(
			array(
				'context' => 'login',   // login | register | checkout | link
				'variant' => 'connect', // connect | create
			),
			$atts,
			'bconnect_button'
		);

		// Sur la page Checkout principale (Blocks ou classique), pas besoin de préciser
		// context="checkout" : auto-détection, sans effet si le marchand le précise déjà,
		// et sans jamais s'appliquer sur order-pay/order-received (is_wc_endpoint_url()).
		if ( ! $context_given && function_exists( 'is_checkout' ) && is_checkout() && ! is_wc_endpoint_url() ) {
			$atts['context'] = 'checkout';
		}

		return $this->render( sanitize_key( $atts['context'] ), sanitize_key( $atts['variant'] ), 'shortcode' );
	}

	public function render_login(): void {
		echo $this->render( 'login', 'connect' ); // phpcs:ignore WordPress.Security.EscapeOutput -- HTML construit et échappé dans le template.
	}

	public function render_register(): void {
		echo $this->render( 'register', 'create' ); // phpcs:ignore WordPress.Security.EscapeOutput
	}

	public function render_checkout(): void {
		echo $this->render( 'checkout', 'connect' ); // phpcs:ignore WordPress.Security.EscapeOutput
	}

	/**
	 * Rendu du bouton. Vide si le plugin n'est pas prêt (jamais de bouton
	 * trompeur, scénario 2) — le mode mock explicitement activé compte
	 * comme prêt, avec badge visible.
	 */
	public function render( string $context, string $variant = 'connect', string $source = 'auto' ): string {
		if ( ! BConnect_Settings::is_ready() ) {
			return current_user_can( 'manage_options' )
				? "\n<!-- b.connect : bouton masqué, configuration incomplète -->\n"
				: '';
		}

		if ( ! in_array( $context, array( 'login', 'register', 'checkout', 'link' ), true ) ) {
			$context = 'login';
		}
		$variant = 'create' === $variant ? 'create' : 'connect';

		// Se connecter/créer un compte n'a de sens que déconnecté ; un utilisateur
		// déjà connecté mais pas encore lié à b.connect se voit proposer l'appairage
		// à la place (pertinent en particulier au checkout, avant paiement).
		if ( in_array( $context, array( 'login', 'register', 'checkout' ), true ) && is_user_logged_in() ) {
			if ( ( new BConnect_User_Resolver() )->is_linked( get_current_user_id() ) ) {
				return '';
			}
			$context = 'link';
		}

		if ( 'link' === $context && ! is_user_logged_in() ) {
			return '';
		}

		$start_url = add_query_arg(
			array(
				'action'  => 'bconnect_start',
				'context' => $context,
				'return'  => rawurlencode( $this->current_url() ),
			),
			admin_url( 'admin-post.php' )
		);
		if ( 'link' === $context ) {
			$start_url = wp_nonce_url( $start_url, 'bconnect_link' );
		}

		// Contexte "link" : bouton officiel générique (sans mention connexion/création),
		// l'action réelle étant un appairage, pas une connexion ni une création de compte.
		// Seule la variante bleue existe pour ce bouton générique (pas d'asset blanc) :
		// le réglage "Thème du bouton" ne s'applique donc pas ici.
		if ( 'link' === $context ) {
			$img     = 'bconnect_largebutton_blue.svg';
			$alt     = __( 'Lier mon compte b.connect', 'wp_bconnect_plugin' );
			$caption = $alt;
		} else {
			$theme   = 'white' === BConnect_Settings::get( 'button_theme' ) ? 'white' : 'blue';
			$img     = sprintf( 'bconnect_largebutton_%s_%s.svg', $variant, $theme );
			$alt     = 'create' === $variant
				? __( 'Créer un compte avec b.connect', 'wp_bconnect_plugin' )
				: __( 'Se connecter avec b.connect', 'wp_bconnect_plugin' );
			$caption = '';
		}

		ob_start();
		$template = BCONNECT_PLUGIN_DIR . 'templates/button.php';
		if ( file_exists( $template ) ) {
			// Variables consommées par le template.
			$bconnect_url     = $start_url;
			$bconnect_img_url = BCONNECT_PLUGIN_URL . 'assets/img/' . $img;
			$bconnect_alt     = $alt;
			$bconnect_caption = $caption;
			$bconnect_context = $context;
			$bconnect_is_mock = BConnect_Settings::is_mock();
			$bconnect_source  = 'shortcode' === $source ? 'shortcode' : 'auto';
			$bconnect_align   = 'center' === BConnect_Settings::get( 'button_align' ) ? 'center' : 'left';
			include $template;
		}
		return (string) ob_get_clean();
	}

	/** Notice sur l'écran de login WordPress. */
	public function login_notice( $message ) {
		$notice = BConnect_Callback::current_notice();
		if ( '' !== $notice ) {
			$message .= '<p class="message bconnect-notice">' . esc_html( $notice ) . '</p>';
		}
		return $message;
	}

	/** Notice sur le front (retour de flow sur une page du site). */
	public function front_notice(): void {
		$notice = BConnect_Callback::current_notice();
		if ( '' !== $notice ) {
			echo '<div class="bconnect-notice bconnect-notice-front" role="status">' . esc_html( $notice ) . '</div>';
		}
	}

	private function current_url(): string {
		$path = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '/';
		$path = remove_query_arg( 'bconnect_notice', $path );

		// REQUEST_URI est déjà relatif à la racine du serveur : il inclut un
		// éventuel sous-répertoire d'installation. On ne reprend donc de home_url()
		// que scheme + host (+ port), sans son chemin, sinon le sous-répertoire
		// serait dupliqué (ex. /boutique/boutique/...). Racine : comportement inchangé.
		$home = wp_parse_url( home_url() );
		$base = ( $home['scheme'] ?? 'https' ) . '://' . ( $home['host'] ?? '' );
		if ( ! empty( $home['port'] ) ) {
			$base .= ':' . $home['port'];
		}
		return $base . $path;
	}
}
