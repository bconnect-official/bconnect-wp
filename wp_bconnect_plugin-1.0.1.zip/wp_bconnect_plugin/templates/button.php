<?php
/**
 * Template du bouton b.connect.
 *
 * Variables fournies par BConnect_Button::render() :
 *
 * @var string $bconnect_url     URL de démarrage du flow.
 * @var string $bconnect_img_url SVG officiel du bouton.
 * @var string $bconnect_alt     Texte alternatif.
 * @var string $bconnect_caption Légende visible sous le bouton (vide si non applicable,
 *                               ex. contexte "link" avec un bouton générique sans texte dédié).
 * @var string $bconnect_context Contexte effectif : login | register | checkout | link.
 * @var bool   $bconnect_is_mock Mode mock actif (badge visible).
 * @var string $bconnect_source  Origine du rendu : 'auto' (hook WordPress/WooCommerce) ou 'shortcode'.
 * @var string $bconnect_align   Alignement voulu par le marchand ('left'|'center') — ne s'applique
 *                                qu'au rendu shortcode, le rendu auto reste centré (comportement historique).
 *
 * Bloc d'accompagnement (slogan + « En savoir plus » + modale) : rendu auto en
 * contexte "login" sur deux emplacements, demande de Lionel — n'affecte ni le
 * shortcode, ni register/checkout/link. Slogan, lien « En savoir plus » et
 * markup de la modale sont COMMUNS aux deux emplacements (aucune duplication) ;
 * seul le séparateur « ou » est spécifique à wp-login.php :
 *   - wp-login.php (action login_form) : séparateur « ou » + slogan + lien +
 *     modale ;
 *   - WooCommerce « Mon compte » déconnecté (action
 *     woocommerce_before_customer_login_form) : slogan + lien + modale, SANS
 *     séparateur « ou ».
 * La modale est pilotée par login-modal.js, chargé sur wp-login.php et, pour le
 * front, uniquement sur « Mon compte » déconnecté (cf. BConnect_Button). Sans ce
 * JS, le lien reste un repli natif ouvrant la page b.connect dans un onglet.
 */

defined( 'ABSPATH' ) || exit;
$bconnect_wrap_classes = 'bconnect-button-wrap bconnect-button-wrap--' . $bconnect_source;
if ( 'link' === $bconnect_context ) {
	$bconnect_wrap_classes .= ' bconnect-button-wrap--link';
}
if ( 'shortcode' === $bconnect_source && 'center' === $bconnect_align ) {
	$bconnect_wrap_classes .= ' bconnect-button-wrap--align-center';
}
?>
<?php
// Bloc d'accompagnement du bouton, uniquement en rendu auto contexte "login".
// Slogan, lien « En savoir plus » et modale sont communs aux deux emplacements ;
// seul le séparateur « ou » reste propre à wp-login.php. Distinction par le hook
// courant (current_action()) :
//   - wp-login.php  -> action login_form : séparateur « ou » + slogan + lien + modale ;
//   - « Mon compte » WooCommerce déconnecté -> action
//     woocommerce_before_customer_login_form : slogan + lien + modale, sans « ou ».
$bconnect_intro_login   = 'login_form' === current_action();
$bconnect_intro_account = 'woocommerce_before_customer_login_form' === current_action();
$bconnect_show_intro    = 'login' === $bconnect_context && 'auto' === $bconnect_source
	&& ( $bconnect_intro_login || $bconnect_intro_account );
?>
<?php if ( $bconnect_show_intro ) : ?>
	<?php
	// Page « En savoir plus » hébergée par b.connect (contenu FR). Sert à la fois
	// de source d'iframe (posée à l'ouverture, côté JS) et de lien de repli
	// ouvrant la page dans un nouvel onglet — fonctionnel sans JavaScript.
	$bconnect_more_url = 'https://www.bconnect.net/modale/fr/modale.htm';
	?>
	<div class="bconnect-login-intro">
		<?php if ( $bconnect_intro_login ) : ?>
			<p class="bconnect-separator"><span><?php esc_html_e( 'ou', 'wp_bconnect_plugin' ); ?></span></p>
		<?php endif; ?>
		<p class="bconnect-pitch"><?php esc_html_e( 'Simplifiez et sécurisez vos connexions grâce à b.connect, la solution souveraine sans mot de passe gratuite portée par les plus grandes banques françaises.', 'wp_bconnect_plugin' ); ?></p>
		<p class="bconnect-more">
			<a class="bconnect-more-link" href="<?php echo esc_url( $bconnect_more_url ); ?>" target="_blank" rel="noopener noreferrer" aria-haspopup="dialog" aria-controls="bconnect-modal" data-bconnect-modal-open><?php esc_html_e( 'En savoir plus', 'wp_bconnect_plugin' ); ?></a>
		</p>
	</div>
	<div id="bconnect-modal" class="bconnect-modal" data-bconnect-modal data-bconnect-modal-src="<?php echo esc_url( $bconnect_more_url ); ?>" role="dialog" aria-modal="true" aria-labelledby="bconnect-modal-title" hidden>
		<div class="bconnect-modal__backdrop" data-bconnect-modal-backdrop></div>
		<div class="bconnect-modal__dialog" role="document">
			<div class="bconnect-modal__header">
				<h2 id="bconnect-modal-title" class="bconnect-modal__title"><?php esc_html_e( 'En savoir plus sur b.connect', 'wp_bconnect_plugin' ); ?></h2>
				<button type="button" class="bconnect-modal__close" data-bconnect-modal-close aria-label="<?php esc_attr_e( 'Fermer', 'wp_bconnect_plugin' ); ?>">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="bconnect-modal__body">
				<p class="bconnect-modal__loading" data-bconnect-modal-loading><?php esc_html_e( 'Chargement du contenu…', 'wp_bconnect_plugin' ); ?></p>
				<iframe class="bconnect-modal__iframe" data-bconnect-modal-iframe title="<?php esc_attr_e( 'En savoir plus sur b.connect', 'wp_bconnect_plugin' ); ?>" sandbox="allow-scripts allow-popups allow-popups-to-escape-sandbox" referrerpolicy="no-referrer"></iframe>
			</div>
		</div>
	</div>
<?php endif; ?>
<div class="<?php echo esc_attr( $bconnect_wrap_classes ); ?>">
	<a class="bconnect-button" href="<?php echo esc_url( $bconnect_url ); ?>" rel="nofollow">
		<img src="<?php echo esc_url( $bconnect_img_url ); ?>" alt="<?php echo esc_attr( $bconnect_alt ); ?>" />
	</a>
	<?php if ( '' !== $bconnect_caption ) : ?>
		<p class="bconnect-button-caption"><?php echo esc_html( $bconnect_caption ); ?></p>
	<?php endif; ?>
	<?php if ( $bconnect_is_mock ) : ?>
		<span class="bconnect-mock-badge"><?php esc_html_e( 'MODE TEST (mock)', 'wp_bconnect_plugin' ); ?></span>
	<?php endif; ?>
</div>
